import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// File system schema for Windows 11 simulation
export const fileItemSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(['folder', 'file']),
  parentId: z.string().nullable(),
  content: z.string().optional(),
  icon: z.string().optional(),
});

export type FileItem = z.infer<typeof fileItemSchema>;

export const insertFileItemSchema = fileItemSchema.omit({ id: true });
export type InsertFileItem = z.infer<typeof insertFileItemSchema>;

// Window state schema
export const windowStateSchema = z.object({
  id: z.string(),
  appId: z.string(),
  title: z.string(),
  isMinimized: z.boolean(),
  isMaximized: z.boolean(),
  x: z.number(),
  y: z.number(),
  width: z.number(),
  height: z.number(),
  zIndex: z.number(),
});

export type WindowState = z.infer<typeof windowStateSchema>;

// App settings schema
export const appSettingsSchema = z.object({
  darkMode: z.boolean(),
  wallpaper: z.string().optional(),
  accentColor: z.string().optional(),
  notepadContent: z.string().optional(),
});

export type AppSettings = z.infer<typeof appSettingsSchema>;
