import { type User, type InsertUser, type FileItem, type InsertFileItem, type AppSettings } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // File system operations
  getFiles(): Promise<FileItem[]>;
  getFileById(id: string): Promise<FileItem | undefined>;
  getFilesByParentId(parentId: string | null): Promise<FileItem[]>;
  createFile(file: InsertFileItem): Promise<FileItem>;
  updateFile(id: string, updates: Partial<FileItem>): Promise<FileItem | undefined>;
  deleteFile(id: string): Promise<boolean>;
  
  // Settings operations
  getSettings(): Promise<AppSettings>;
  updateSettings(settings: Partial<AppSettings>): Promise<AppSettings>;
}

const defaultFiles: FileItem[] = [
  { id: 'desktop', name: 'Desktop', type: 'folder', parentId: null },
  { id: 'documents', name: 'Documents', type: 'folder', parentId: null },
  { id: 'downloads', name: 'Downloads', type: 'folder', parentId: null },
  { id: 'pictures', name: 'Pictures', type: 'folder', parentId: null },
  { id: 'music', name: 'Music', type: 'folder', parentId: null },
  { id: 'videos', name: 'Videos', type: 'folder', parentId: null },
  { id: 'file1', name: 'Welcome.txt', type: 'file', parentId: 'documents', content: 'Welcome to Windows 11!\n\nThis is a simulated Windows 11 desktop environment running in your web browser.\n\nFeatures:\n- Desktop icons and wallpaper\n- Start menu with pinned apps\n- Working calculator\n- Notepad for text editing\n- File Explorer\n- Settings app\n- Microsoft Edge browser\n- Action Center\n- Widgets panel\n\nEnjoy exploring!' },
  { id: 'file2', name: 'Notes.txt', type: 'file', parentId: 'documents', content: 'My notes go here...\n\nTODO:\n- Learn more about Windows 11\n- Explore the apps\n- Customize settings' },
  { id: 'folder1', name: 'Projects', type: 'folder', parentId: 'documents' },
  { id: 'file3', name: 'Screenshot.png', type: 'file', parentId: 'pictures' },
  { id: 'file4', name: 'Wallpaper.jpg', type: 'file', parentId: 'pictures' },
  { id: 'file5', name: 'Meeting Recording.mp4', type: 'file', parentId: 'videos' },
  { id: 'file6', name: 'Favorite Song.mp3', type: 'file', parentId: 'music' },
];

const defaultSettings: AppSettings = {
  darkMode: true,
  wallpaper: 'bloom-blue',
  accentColor: '#0078d4',
  notepadContent: '',
};

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private files: Map<string, FileItem>;
  private settings: AppSettings;

  constructor() {
    this.users = new Map();
    this.files = new Map();
    this.settings = { ...defaultSettings };
    
    // Initialize default files
    defaultFiles.forEach(file => {
      this.files.set(file.id, file);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // File system operations
  async getFiles(): Promise<FileItem[]> {
    return Array.from(this.files.values());
  }

  async getFileById(id: string): Promise<FileItem | undefined> {
    return this.files.get(id);
  }

  async getFilesByParentId(parentId: string | null): Promise<FileItem[]> {
    return Array.from(this.files.values()).filter(
      (file) => file.parentId === parentId
    );
  }

  async createFile(insertFile: InsertFileItem): Promise<FileItem> {
    const id = `file-${Date.now()}-${randomUUID().slice(0, 8)}`;
    const file: FileItem = { ...insertFile, id };
    this.files.set(id, file);
    return file;
  }

  async updateFile(id: string, updates: Partial<FileItem>): Promise<FileItem | undefined> {
    const file = this.files.get(id);
    if (!file) return undefined;
    
    const updatedFile = { ...file, ...updates };
    this.files.set(id, updatedFile);
    return updatedFile;
  }

  async deleteFile(id: string): Promise<boolean> {
    return this.files.delete(id);
  }

  // Settings operations
  async getSettings(): Promise<AppSettings> {
    return { ...this.settings };
  }

  async updateSettings(updates: Partial<AppSettings>): Promise<AppSettings> {
    this.settings = { ...this.settings, ...updates };
    return { ...this.settings };
  }
}

export const storage = new MemStorage();
