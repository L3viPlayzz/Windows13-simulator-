import { useWindowsStore } from '@/lib/windows-store';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  RefreshCw, 
  Eye, 
  ArrowUpDown, 
  Plus, 
  Monitor, 
  Palette,
  Terminal,
  Folder,
  FileText,
  Scissors,
  Copy,
  ClipboardPaste,
  Trash2,
  Info
} from 'lucide-react';

const iconMap: Record<string, typeof RefreshCw> = {
  'View': Eye,
  'Sort by': ArrowUpDown,
  'Refresh': RefreshCw,
  'New': Plus,
  'Display settings': Monitor,
  'Personalize': Palette,
  'Open in Terminal': Terminal,
  'New folder': Folder,
  'New file': FileText,
  'Cut': Scissors,
  'Copy': Copy,
  'Paste': ClipboardPaste,
  'Delete': Trash2,
  'Properties': Info,
};

export function ContextMenu() {
  const { contextMenu, hideContextMenu } = useWindowsStore();

  if (!contextMenu) return null;

  const menuStyle = {
    left: Math.min(contextMenu.x, window.innerWidth - 240),
    top: Math.min(contextMenu.y, window.innerHeight - 300),
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.1 }}
        className="context-menu fixed z-[9999] bg-background/95 dark:bg-card/95"
        style={menuStyle}
        onClick={(e) => e.stopPropagation()}
        data-testid="context-menu"
      >
        {contextMenu.items.map((item, index) => {
          if (item.divider) {
            return (
              <div 
                key={index} 
                className="h-px bg-border my-1.5 mx-2" 
              />
            );
          }

          const Icon = iconMap[item.label] || Eye;

          return (
            <button
              key={index}
              className={`context-menu-item w-full text-foreground ${
                item.disabled ? 'opacity-50 cursor-not-allowed' : ''
              }`}
              onClick={() => {
                if (!item.disabled && item.action) {
                  item.action();
                }
                hideContextMenu();
              }}
              disabled={item.disabled}
              data-testid={`context-menu-item-${index}`}
            >
              <Icon className="w-4 h-4 text-muted-foreground" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </motion.div>
    </AnimatePresence>
  );
}
