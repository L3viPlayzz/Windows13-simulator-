import { useWindowsStore } from '@/lib/windows-store';
import { 
  Search, 
  Power, 
  User, 
  Settings, 
  Folder, 
  Globe, 
  Calculator,
  FileText,
  Monitor,
  Image,
  Music,
  Video,
  Mail,
  Calendar,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRef, useEffect } from 'react';

const pinnedApps = [
  { id: 'explorer', Icon: Folder, name: 'File Explorer' },
  { id: 'settings', Icon: Settings, name: 'Settings' },
  { id: 'notepad', Icon: FileText, name: 'Notepad' },
  { id: 'calculator', Icon: Calculator, name: 'Calculator' },
  { id: 'photos', Icon: Image, name: 'Photos' },
  { id: 'mail', Icon: Mail, name: 'Mail' },
  { id: 'edge', Icon: Globe, name: 'Microsoft Edge' },
  { id: 'this-pc', Icon: Monitor, name: 'This PC' },
  { id: 'calendar', Icon: Calendar, name: 'Calendar' },
  { id: 'music', Icon: Music, name: 'Groove Music' },
  { id: 'video', Icon: Video, name: 'Movies & TV' },
];

const recommendedItems = [
  { id: 'rec1', name: 'Welcome.txt', type: 'Recently added', Icon: FileText },
  { id: 'rec2', name: 'Documents', type: 'Folder', Icon: Folder },
  { id: 'rec3', name: 'Getting Started', type: 'Suggested', Icon: Globe },
  { id: 'rec4', name: 'Notes.txt', type: 'Recently opened', Icon: FileText },
];

export function StartMenu() {
  const { startMenuOpen, closeStartMenu, openWindow, userName, setUserName, darkMode } = useWindowsStore();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (menuRef.current) {
      menuRef.current.style.backgroundColor = darkMode 
        ? 'rgba(20, 25, 40, 0.92)' 
        : 'rgba(255, 255, 255, 0.92)';
    }
  }, [darkMode]);

  const handleAppClick = (appId: string, name: string) => {
    const appConfig: Record<string, { width: number; height: number }> = {
      calculator: { width: 320, height: 500 },
      notepad: { width: 700, height: 500 },
      explorer: { width: 900, height: 600 },
      settings: { width: 1000, height: 700 },
      edge: { width: 1200, height: 800 },
      photos: { width: 1000, height: 700 },
      mail: { width: 1000, height: 700 },
      calendar: { width: 900, height: 600 },
      music: { width: 900, height: 600 },
      video: { width: 1000, height: 700 },
      'this-pc': { width: 900, height: 600 },
    };
    
    const config = appConfig[appId] || { width: 800, height: 600 };
    openWindow(appId, name, config.width, config.height);
    closeStartMenu();
  };

  return (
    <AnimatePresence>
      {startMenuOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40"
            onClick={closeStartMenu}
            data-testid="start-menu-backdrop"
          />
          <motion.div
            ref={menuRef}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="win-acrylic win-border win-shadow rounded-2xl z-50 flex flex-col overflow-hidden text-foreground"
            style={{ 
              width: '630px',
              backdropFilter: 'blur(20px)', 
              maxHeight: '80vh'
            }}
            data-testid="start-menu"
          >
            {/* Search Bar */}
            <div className="p-5 pb-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Type here to search"
                  className="w-full h-10 pl-10 pr-4 rounded-full bg-primary/8 border border-primary/20 text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 shadow-sm"
                  data-testid="input-start-search"
                />
              </div>
            </div>

            {/* Pinned Section */}
            <div className="px-5 py-1">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-sm font-semibold text-foreground">Pinned</h2>
                <button className="flex items-center gap-1 text-xs text-foreground/70 hover:text-foreground px-2 py-1 rounded hover:bg-white/10 transition-colors">
                  All apps <ChevronRight className="w-3 h-3" />
                </button>
              </div>
              
              <div className="grid grid-cols-6 gap-2 mb-4">
                {pinnedApps.slice(0, 8).map(({ id, Icon, name }) => (
                  <button
                    key={id}
                    className="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-white/10 transition-colors"
                    onClick={() => handleAppClick(id, name)}
                    data-testid={`start-app-${id}`}
                  >
                    <Icon className="w-10 h-10 text-blue-400 mb-1" strokeWidth={1.5} />
                    <span className="text-xs text-center text-foreground truncate w-full">
                      {name}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Recommended Section */}
            <div className="px-5 py-1 border-t border-primary/10">
              <div className="flex items-center justify-between mb-3 pt-3">
                <h2 className="text-sm font-semibold text-foreground">Recommended</h2>
                <button className="flex items-center gap-1 text-xs text-foreground/70 hover:text-foreground px-2 py-1 rounded hover:bg-white/10 transition-colors">
                  More <ChevronRight className="w-3 h-3" />
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-2 mb-4">
                {recommendedItems.map(({ id, name, type, Icon }) => (
                  <button
                    key={id}
                    className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-white/10 transition-colors text-left"
                    onClick={() => handleAppClick('notepad', name)}
                    data-testid={`start-recommended-${id}`}
                  >
                    <Icon className="w-9 h-9 text-blue-400 flex-shrink-0" strokeWidth={1.5} />
                    <div className="flex flex-col items-start min-w-0">
                      <span className="text-sm text-foreground truncate font-medium">{name}</span>
                      <span className="text-xs text-foreground/60 truncate">{type}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-6 py-3 border-t border-primary/10 bg-primary/5">
              <button 
                className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-white/10 transition-colors"
                data-testid="button-user-profile"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-300 to-blue-400 flex items-center justify-center flex-shrink-0">
                  <User className="w-5 h-5 text-foreground" />
                </div>
                <input 
                  type="text" 
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="text-sm text-foreground font-medium bg-transparent border-b border-white/30 focus:outline-none focus:border-white px-1"
                />
              </button>
              
              <button 
                className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-white/10 transition-colors"
                data-testid="button-power"
              >
                <Power className="w-5 h-5 text-foreground" />
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
