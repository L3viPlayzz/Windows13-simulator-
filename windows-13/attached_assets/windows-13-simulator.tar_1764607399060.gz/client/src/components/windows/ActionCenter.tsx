import { useWindowsStore } from '@/lib/windows-store';
import { 
  Wifi, 
  Bluetooth, 
  Plane, 
  Moon, 
  Sun,
  Battery,
  Cast,
  Accessibility,
  Focus,
  Volume2,
  Sun as Brightness,
  Settings,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Slider } from '@/components/ui/slider';
import { useState, useRef, useEffect } from 'react';

export function ActionCenter() {
  const { actionCenterOpen, closeActionCenter, darkMode, toggleDarkMode, openWindow } = useWindowsStore();
  const [volume, setVolume] = useState([75]);
  const [brightness, setBrightness] = useState([100]);
  const [wifiOn, setWifiOn] = useState(true);
  const [bluetoothOn, setBluetoothOn] = useState(false);
  const [airplaneMode, setAirplaneMode] = useState(false);
  const [focusAssist, setFocusAssist] = useState(false);
  const [accessibility, setAccessibility] = useState(false);
  const [cast, setCast] = useState(false);
  const centerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (centerRef.current) {
      centerRef.current.style.backgroundColor = darkMode 
        ? 'rgba(20, 25, 40, 0.95)' 
        : 'rgba(255, 255, 255, 0.95)';
    }
  }, [darkMode]);

  const quickSettings = [
    { id: 'wifi', Icon: Wifi, name: 'Wi-Fi', active: wifiOn, toggle: () => setWifiOn(!wifiOn) },
    { id: 'bluetooth', Icon: Bluetooth, name: 'Bluetooth', active: bluetoothOn, toggle: () => setBluetoothOn(!bluetoothOn) },
    { id: 'airplane', Icon: Plane, name: 'Airplane', active: airplaneMode, toggle: () => setAirplaneMode(!airplaneMode) },
    { id: 'battery', Icon: Battery, name: 'Battery', active: false, toggle: () => {} },
    { id: 'focus', Icon: Focus, name: 'Focus', active: focusAssist, toggle: () => setFocusAssist(!focusAssist) },
    { id: 'accessibility', Icon: Accessibility, name: 'Accessibility', active: accessibility, toggle: () => setAccessibility(!accessibility) },
    { id: 'cast', Icon: Cast, name: 'Cast', active: cast, toggle: () => setCast(!cast) },
    { id: 'night', Icon: darkMode ? Sun : Moon, name: darkMode ? 'Light' : 'Dark', active: darkMode, toggle: toggleDarkMode },
  ];

  return (
    <AnimatePresence>
      {actionCenterOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0"
            onClick={closeActionCenter}
            data-testid="action-center-backdrop"
          />
          <motion.div
            ref={centerRef}
            initial={{ opacity: 0, x: 20, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 20, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="fixed bottom-14 right-2 w-[380px] win-acrylic win-border win-shadow rounded-lg z-50 p-4 text-foreground"
            data-testid="action-center"
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">Quick Settings</h3>
              <button 
                onClick={closeActionCenter}
                className="p-1 hover:bg-accent/50 rounded-md transition-colors"
                data-testid="button-close-action-center"
              >
                <X className="w-4 h-4 text-foreground" />
              </button>
            </div>

            {/* Quick Settings Grid */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              {quickSettings.map(({ id, Icon, name, active, toggle }) => (
                <button
                  key={id}
                  className={`flex flex-col items-center gap-2 p-3 rounded-md transition-colors ${
                    active 
                      ? 'bg-accent/40 text-accent' 
                      : 'hover:bg-muted text-foreground'
                  }`}
                  onClick={toggle}
                  data-testid={`quick-setting-${id}`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs text-center leading-tight">{name}</span>
                </button>
              ))}
            </div>

            {/* Sliders */}
            <div className="space-y-4 mb-4 pt-4 border-t border-border">
              <div className="flex items-center gap-3">
                <Brightness className="w-4 h-4 text-muted-foreground shrink-0" />
                <Slider
                  value={brightness}
                  onValueChange={setBrightness}
                  max={100}
                  step={1}
                  className="flex-1"
                  data-testid="slider-brightness"
                />
                <span className="text-xs text-muted-foreground w-8 text-right">{brightness[0]}%</span>
              </div>
              <div className="flex items-center gap-3">
                <Volume2 className="w-4 h-4 text-muted-foreground shrink-0" />
                <Slider
                  value={volume}
                  onValueChange={setVolume}
                  max={100}
                  step={1}
                  className="flex-1"
                  data-testid="slider-volume"
                />
                <span className="text-xs text-muted-foreground w-8 text-right">{volume[0]}%</span>
              </div>
            </div>

            {/* Battery and Settings */}
            <div className="flex items-center justify-between pt-4 border-t border-border">
              <div className="flex items-center gap-2 text-sm text-foreground">
                <Battery className="w-4 h-4" />
                <span>Battery 85%</span>
              </div>
              <button
                className="p-2 rounded-md hover:bg-accent/30 transition-colors"
                onClick={() => {
                  openWindow('settings', 'Settings', 1000, 700);
                  closeActionCenter();
                }}
                data-testid="button-action-settings"
              >
                <Settings className="w-4 h-4 text-foreground" />
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
