import { motion } from 'framer-motion';
import { useEffect } from 'react';

export function StartupAnimation({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    // Na 3 seconden animatie compleet - windows zichtbaar maken
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
      className="fixed inset-0 bg-gradient-to-b from-slate-900 to-black z-[9999] flex flex-col items-center justify-center gap-8"
    >
      <motion.div
        initial={{ scale: 0.3, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1, ease: "easeOut" }}
        className="relative"
      >
        <svg className="w-32 h-32 text-cyan-400" viewBox="0 0 100 100" fill="currentColor">
          <rect x="10" y="10" width="35" height="35" fill="currentColor" />
          <rect x="55" y="10" width="35" height="35" fill="currentColor" />
          <rect x="10" y="55" width="35" height="35" fill="currentColor" />
          <rect x="55" y="55" width="35" height="35" fill="currentColor" />
        </svg>
      </motion.div>

      <div className="flex gap-2">
        {[0, 1, 2, 3].map((i) => (
          <motion.div
            key={i}
            className="w-2 h-2 bg-cyan-400 rounded-full"
            animate={{ opacity: [0.4, 1, 0.4], scale: [1, 1.3, 1] }}
            transition={{ duration: 2, delay: i * 0.2, repeat: Infinity, ease: "easeInOut" }}
          />
        ))}
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.6 }}
        className="text-cyan-400 text-lg font-light"
      >
        Starting up...
      </motion.p>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 3, duration: 0.3 }}
        onAnimationComplete={onComplete}
        className="absolute inset-0"
      />
    </motion.div>
  );
}
