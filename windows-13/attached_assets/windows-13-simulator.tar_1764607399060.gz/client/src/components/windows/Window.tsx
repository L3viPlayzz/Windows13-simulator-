import { useWindowsStore, WindowState } from '@/lib/windows-store';
import { Minus, Square, X, Copy } from 'lucide-react';
import { useRef, useEffect, useState, useCallback } from 'react';

interface WindowProps {
  window: WindowState;
  children: React.ReactNode;
}

export function Window({ window, children }: WindowProps) {
  const { 
    activeWindowId, 
    focusWindow, 
    closeWindow, 
    minimizeWindow, 
    maximizeWindow,
    restoreWindow,
    moveWindow,
    resizeWindow,
  } = useWindowsStore();
  
  const windowRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [resizeDirection, setResizeDirection] = useState<string | null>(null);
  const [initialSize, setInitialSize] = useState({ width: 0, height: 0 });
  const [initialPos, setInitialPos] = useState({ x: 0, y: 0 });
  const [mouseStart, setMouseStart] = useState({ x: 0, y: 0 });

  const isActive = activeWindowId === window.id;

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (e.target instanceof HTMLElement && e.target.closest('.window-title-btn')) {
      return;
    }
    
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - window.x,
      y: e.clientY - window.y,
    });
    focusWindow(window.id);
  }, [window.x, window.y, window.id, focusWindow]);

  // RAF-based throttling for smooth 60fps dragging
  const rafRef = useRef<number>();

  const handleResizeStart = useCallback((e: React.MouseEvent, direction: string) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(true);
    setResizeDirection(direction);
    setInitialSize({ width: window.width, height: window.height });
    setInitialPos({ x: window.x, y: window.y });
    setMouseStart({ x: e.clientX, y: e.clientY });
    focusWindow(window.id);
  }, [window.width, window.height, window.x, window.y, window.id, focusWindow]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDragging && !window.isMaximized) {
        // Use requestAnimationFrame to throttle to 60fps
        if (rafRef.current) cancelAnimationFrame(rafRef.current);
        rafRef.current = requestAnimationFrame(() => {
          const newX = Math.max(0, Math.min(e.clientX - dragOffset.x, globalThis.innerWidth - 100));
          const newY = Math.max(0, Math.min(e.clientY - dragOffset.y, globalThis.innerHeight - 100));
          moveWindow(window.id, newX, newY);
        });
      }
      
      if (isResizing && resizeDirection) {
        const deltaX = e.clientX - mouseStart.x;
        const deltaY = e.clientY - mouseStart.y;
        
        let newWidth = initialSize.width;
        let newHeight = initialSize.height;
        let newX = initialPos.x;
        let newY = initialPos.y;
        
        if (resizeDirection.includes('e')) {
          newWidth = Math.max(300, initialSize.width + deltaX);
        }
        if (resizeDirection.includes('w')) {
          newWidth = Math.max(300, initialSize.width - deltaX);
          newX = initialPos.x + deltaX;
        }
        if (resizeDirection.includes('s')) {
          newHeight = Math.max(200, initialSize.height + deltaY);
        }
        if (resizeDirection.includes('n')) {
          newHeight = Math.max(200, initialSize.height - deltaY);
          newY = initialPos.y + deltaY;
        }
        
        resizeWindow(window.id, newWidth, newHeight);
        if (resizeDirection.includes('w') || resizeDirection.includes('n')) {
          moveWindow(window.id, newX, newY);
        }
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
      setResizeDirection(null);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };

    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove, { passive: true });
      document.addEventListener('mouseup', handleMouseUp, { passive: false });
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [isDragging, isResizing, dragOffset, resizeDirection, initialSize, initialPos, mouseStart, window.id, window.isMaximized, moveWindow, resizeWindow]);

  if (window.isMinimized) {
    return null;
  }

  const windowStyle = window.isMaximized
    ? {
        left: 0,
        top: 0,
        width: '100%',
        height: 'calc(100vh - 48px)',
        zIndex: window.zIndex,
      }
    : {
        left: window.x,
        top: window.y,
        width: window.width,
        height: window.height,
        zIndex: window.zIndex,
      };

  return (
    <div
      ref={windowRef}
      className={`fixed bg-background dark:bg-card rounded-lg overflow-hidden flex flex-col ${
        isActive ? 'win-shadow' : 'shadow-lg'
      } ${window.isMaximized ? 'rounded-none' : ''}`}
      style={windowStyle}
      onClick={() => focusWindow(window.id)}
      data-testid={`window-${window.appId}`}
    >
      {/* Title Bar */}
      <div
        className="h-8 flex items-center justify-between bg-card/90 dark:bg-card select-none shrink-0 border-b border-card-border"
        onMouseDown={handleMouseDown}
        onDoubleClick={() => window.isMaximized ? restoreWindow(window.id) : maximizeWindow(window.id)}
      >
        <div className="flex items-center gap-2 px-3">
          <span className="text-xs font-medium text-foreground">{window.title}</span>
        </div>
        
        <div className="flex items-center">
          <button
            className="window-title-btn text-foreground"
            onClick={() => minimizeWindow(window.id)}
            data-testid={`button-minimize-${window.appId}`}
          >
            <Minus className="w-4 h-4" />
          </button>
          <button
            className="window-title-btn text-foreground"
            onClick={() => window.isMaximized ? restoreWindow(window.id) : maximizeWindow(window.id)}
            data-testid={`button-maximize-${window.appId}`}
          >
            {window.isMaximized ? <Copy className="w-3 h-3" /> : <Square className="w-3 h-3" />}
          </button>
          <button
            className="window-title-btn close text-foreground"
            onClick={() => closeWindow(window.id)}
            data-testid={`button-close-${window.appId}`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {children}
      </div>

      {/* Resize Handles */}
      {!window.isMaximized && (
        <>
          <div
            className="absolute window-frame top-0 left-0 right-0 h-1 cursor-n-resize"
            onMouseDown={(e) => handleResizeStart(e, 'n')}
          />
          <div
            className="absolute window-frame bottom-0 left-0 right-0 h-1 cursor-s-resize"
            onMouseDown={(e) => handleResizeStart(e, 's')}
          />
          <div
            className="absolute window-frame top-0 bottom-0 left-0 w-1 cursor-w-resize"
            onMouseDown={(e) => handleResizeStart(e, 'w')}
          />
          <div
            className="absolute window-frame top-0 bottom-0 right-0 w-1 cursor-e-resize"
            onMouseDown={(e) => handleResizeStart(e, 'e')}
          />
          <div
            className="absolute window-frame top-0 left-0 w-3 h-3 cursor-nw-resize"
            onMouseDown={(e) => handleResizeStart(e, 'nw')}
          />
          <div
            className="absolute window-frame top-0 right-0 w-3 h-3 cursor-ne-resize"
            onMouseDown={(e) => handleResizeStart(e, 'ne')}
          />
          <div
            className="absolute window-frame bottom-0 left-0 w-3 h-3 cursor-sw-resize"
            onMouseDown={(e) => handleResizeStart(e, 'sw')}
          />
          <div
            className="absolute window-frame bottom-0 right-0 w-3 h-3 cursor-se-resize"
            onMouseDown={(e) => handleResizeStart(e, 'se')}
          />
        </>
      )}
    </div>
  );
}
