import { useState, useCallback } from 'react';
import { Delete } from 'lucide-react';

export function Calculator() {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<string | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);

  const inputDigit = useCallback((digit: string) => {
    if (waitingForOperand) {
      setDisplay(digit);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? digit : display + digit);
    }
  }, [display, waitingForOperand]);

  const inputDecimal = useCallback(() => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
    } else if (!display.includes('.')) {
      setDisplay(display + '.');
    }
  }, [display, waitingForOperand]);

  const clear = useCallback(() => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(false);
  }, []);

  const clearEntry = useCallback(() => {
    setDisplay('0');
  }, []);

  const backspace = useCallback(() => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay('0');
    }
  }, [display]);

  const toggleSign = useCallback(() => {
    const value = parseFloat(display);
    setDisplay(String(-value));
  }, [display]);

  const inputPercent = useCallback(() => {
    const value = parseFloat(display);
    setDisplay(String(value / 100));
  }, [display]);

  const performOperation = useCallback((nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(display);
    } else if (operation) {
      const prevValue = parseFloat(previousValue);
      let result: number;

      switch (operation) {
        case '+':
          result = prevValue + inputValue;
          break;
        case '-':
          result = prevValue - inputValue;
          break;
        case '×':
          result = prevValue * inputValue;
          break;
        case '÷':
          result = prevValue / inputValue;
          break;
        default:
          result = inputValue;
      }

      setDisplay(String(result));
      setPreviousValue(String(result));
    }

    setWaitingForOperand(true);
    setOperation(nextOperation);
  }, [display, operation, previousValue]);

  const calculate = useCallback(() => {
    if (!operation || previousValue === null) return;

    const inputValue = parseFloat(display);
    const prevValue = parseFloat(previousValue);
    let result: number;

    switch (operation) {
      case '+':
        result = prevValue + inputValue;
        break;
      case '-':
        result = prevValue - inputValue;
        break;
      case '×':
        result = prevValue * inputValue;
        break;
      case '÷':
        result = prevValue / inputValue;
        break;
      default:
        return;
    }

    setDisplay(String(result));
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(true);
  }, [display, operation, previousValue]);

  const formatDisplay = (value: string) => {
    const num = parseFloat(value);
    if (isNaN(num)) return value;
    if (value.includes('.') && value.endsWith('.')) return value;
    if (Math.abs(num) >= 1e10) return num.toExponential(4);
    return num.toLocaleString('en-US', { maximumFractionDigits: 10 });
  };

  return (
    <div className="h-full flex flex-col bg-background dark:bg-card p-3">
      {/* Display */}
      <div className="mb-2">
        <div className="text-right text-sm text-muted-foreground h-5">
          {previousValue && operation ? `${formatDisplay(previousValue)} ${operation}` : ''}
        </div>
        <div 
          className="text-right text-4xl font-light text-foreground truncate"
          data-testid="calc-display"
        >
          {formatDisplay(display)}
        </div>
      </div>

      {/* Memory buttons row - simplified */}
      <div className="grid grid-cols-4 gap-1 mb-1">
        <button className="calc-btn text-muted-foreground text-sm" disabled>MC</button>
        <button className="calc-btn text-muted-foreground text-sm" disabled>MR</button>
        <button className="calc-btn text-muted-foreground text-sm" disabled>M+</button>
        <button className="calc-btn text-muted-foreground text-sm" disabled>M-</button>
      </div>

      {/* Main buttons grid */}
      <div className="grid grid-cols-4 gap-1 flex-1">
        <button 
          className="calc-btn operator text-foreground" 
          onClick={() => inputPercent()}
          data-testid="calc-btn-percent"
        >
          %
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={clearEntry}
          data-testid="calc-btn-ce"
        >
          CE
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={clear}
          data-testid="calc-btn-c"
        >
          C
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={backspace}
          data-testid="calc-btn-backspace"
        >
          <Delete className="w-5 h-5 mx-auto" />
        </button>

        <button 
          className="calc-btn operator text-foreground" 
          onClick={() => {
            const value = parseFloat(display);
            setDisplay(String(1 / value));
          }}
          data-testid="calc-btn-reciprocal"
        >
          1/x
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={() => {
            const value = parseFloat(display);
            setDisplay(String(value * value));
          }}
          data-testid="calc-btn-square"
        >
          x²
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={() => {
            const value = parseFloat(display);
            setDisplay(String(Math.sqrt(value)));
          }}
          data-testid="calc-btn-sqrt"
        >
          √x
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={() => performOperation('÷')}
          data-testid="calc-btn-divide"
        >
          ÷
        </button>

        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('7')}
          data-testid="calc-btn-7"
        >
          7
        </button>
        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('8')}
          data-testid="calc-btn-8"
        >
          8
        </button>
        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('9')}
          data-testid="calc-btn-9"
        >
          9
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={() => performOperation('×')}
          data-testid="calc-btn-multiply"
        >
          ×
        </button>

        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('4')}
          data-testid="calc-btn-4"
        >
          4
        </button>
        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('5')}
          data-testid="calc-btn-5"
        >
          5
        </button>
        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('6')}
          data-testid="calc-btn-6"
        >
          6
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={() => performOperation('-')}
          data-testid="calc-btn-subtract"
        >
          −
        </button>

        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('1')}
          data-testid="calc-btn-1"
        >
          1
        </button>
        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('2')}
          data-testid="calc-btn-2"
        >
          2
        </button>
        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('3')}
          data-testid="calc-btn-3"
        >
          3
        </button>
        <button 
          className="calc-btn operator text-foreground" 
          onClick={() => performOperation('+')}
          data-testid="calc-btn-add"
        >
          +
        </button>

        <button 
          className="calc-btn text-foreground" 
          onClick={toggleSign}
          data-testid="calc-btn-sign"
        >
          ±
        </button>
        <button 
          className="calc-btn text-foreground" 
          onClick={() => inputDigit('0')}
          data-testid="calc-btn-0"
        >
          0
        </button>
        <button 
          className="calc-btn text-foreground" 
          onClick={inputDecimal}
          data-testid="calc-btn-decimal"
        >
          .
        </button>
        <button 
          className="calc-btn equals" 
          onClick={calculate}
          data-testid="calc-btn-equals"
        >
          =
        </button>
      </div>
    </div>
  );
}
