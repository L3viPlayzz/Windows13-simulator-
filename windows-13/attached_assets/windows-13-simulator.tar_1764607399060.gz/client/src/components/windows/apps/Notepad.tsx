import { useWindowsStore } from '@/lib/windows-store';
import { useState } from 'react';
import { 
  File, 
  FolderOpen, 
  Save, 
  Undo, 
  Redo, 
  Scissors, 
  Copy, 
  ClipboardPaste,
  Search,
  ZoomIn,
  ZoomOut
} from 'lucide-react';

export function Notepad() {
  const { notepadContent, setNotepadContent } = useWindowsStore();
  const [zoom, setZoom] = useState(100);

  const menuItems = [
    { label: 'File', items: ['New', 'Open', 'Save', 'Save as', 'Print'] },
    { label: 'Edit', items: ['Undo', 'Redo', 'Cut', 'Copy', 'Paste', 'Find', 'Replace'] },
    { label: 'View', items: ['Zoom In', 'Zoom Out', 'Status Bar', 'Word Wrap'] },
  ];

  const toolbarItems = [
    { Icon: File, action: () => setNotepadContent(''), title: 'New' },
    { Icon: FolderOpen, action: () => {}, title: 'Open' },
    { Icon: Save, action: () => {}, title: 'Save' },
    { divider: true },
    { Icon: Undo, action: () => {}, title: 'Undo' },
    { Icon: Redo, action: () => {}, title: 'Redo' },
    { divider: true },
    { Icon: Scissors, action: () => {}, title: 'Cut' },
    { Icon: Copy, action: () => {}, title: 'Copy' },
    { Icon: ClipboardPaste, action: () => {}, title: 'Paste' },
    { divider: true },
    { Icon: Search, action: () => {}, title: 'Find' },
    { Icon: ZoomIn, action: () => setZoom(Math.min(zoom + 10, 200)), title: 'Zoom In' },
    { Icon: ZoomOut, action: () => setZoom(Math.max(zoom - 10, 50)), title: 'Zoom Out' },
  ];

  const lineCount = notepadContent.split('\n').length;
  const charCount = notepadContent.length;

  return (
    <div className="h-full flex flex-col bg-background dark:bg-card">
      {/* Menu Bar */}
      <div className="flex items-center gap-1 px-2 py-1 border-b border-border bg-card/50">
        {menuItems.map(({ label }) => (
          <button
            key={label}
            className="px-3 py-1 text-sm text-foreground rounded hover:bg-accent"
            data-testid={`notepad-menu-${label.toLowerCase()}`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-1 px-2 py-1 border-b border-border bg-card/30">
        {toolbarItems.map((item, index) => {
          if ('divider' in item) {
            return <div key={index} className="w-px h-6 bg-border mx-1" />;
          }
          
          return (
            <button
              key={index}
              className="p-1.5 rounded hover:bg-accent"
              onClick={item.action}
              title={item.title}
              data-testid={`notepad-tool-${item.title?.toLowerCase().replace(' ', '-')}`}
            >
              <item.Icon className="w-4 h-4 text-foreground" />
            </button>
          );
        })}
      </div>

      {/* Text Area */}
      <div className="flex-1 overflow-hidden">
        <textarea
          value={notepadContent}
          onChange={(e) => setNotepadContent(e.target.value)}
          className="w-full h-full p-4 resize-none bg-transparent text-foreground focus:outline-none font-mono"
          style={{ fontSize: `${zoom}%` }}
          placeholder="Start typing..."
          spellCheck={false}
          data-testid="notepad-textarea"
        />
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 py-1 border-t border-border bg-card/50 text-xs text-muted-foreground">
        <div className="flex items-center gap-4">
          <span>Ln 1, Col 1</span>
          <span>{charCount} characters</span>
          <span>{lineCount} lines</span>
        </div>
        <div className="flex items-center gap-4">
          <span>{zoom}%</span>
          <span>UTF-8</span>
          <span>Windows (CRLF)</span>
        </div>
      </div>
    </div>
  );
}
