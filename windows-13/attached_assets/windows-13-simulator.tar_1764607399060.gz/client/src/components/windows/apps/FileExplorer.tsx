import { useWindowsStore, FileItem } from '@/lib/windows-store';
import { 
  ChevronLeft, 
  ChevronRight, 
  ChevronUp, 
  RefreshCw,
  Search,
  LayoutGrid,
  List,
  Folder,
  FileText,
  Image,
  Music,
  Video,
  Monitor,
  HardDrive,
  Download,
  File,
  Plus,
  Scissors,
  Copy,
  ClipboardPaste,
  Trash2,
  MoreHorizontal
} from 'lucide-react';
import { useState } from 'react';

const quickAccessItems = [
  { id: 'desktop', name: 'Desktop', Icon: Monitor },
  { id: 'downloads', name: 'Downloads', Icon: Download },
  { id: 'documents', name: 'Documents', Icon: FileText },
  { id: 'pictures', name: 'Pictures', Icon: Image },
  { id: 'music', name: 'Music', Icon: Music },
  { id: 'videos', name: 'Videos', Icon: Video },
];

const getFileIcon = (item: FileItem) => {
  if (item.type === 'folder') return Folder;
  if (item.name.endsWith('.txt')) return FileText;
  if (item.name.endsWith('.png') || item.name.endsWith('.jpg')) return Image;
  if (item.name.endsWith('.mp3')) return Music;
  if (item.name.endsWith('.mp4')) return Video;
  return File;
};

export function FileExplorer() {
  const { files, currentFolderId, navigateToFolder } = useWindowsStore();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');

  const currentFolder = currentFolderId 
    ? files.find(f => f.id === currentFolderId)
    : null;

  const currentFiles = files.filter(f => f.parentId === currentFolderId);

  const breadcrumbs: FileItem[] = [];
  let tempFolder = currentFolder;
  while (tempFolder) {
    breadcrumbs.unshift(tempFolder);
    tempFolder = tempFolder.parentId 
      ? files.find(f => f.id === tempFolder!.parentId)
      : undefined;
  }

  const filteredFiles = searchQuery
    ? currentFiles.filter(f => 
        f.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : currentFiles;

  const handleItemDoubleClick = (item: FileItem) => {
    if (item.type === 'folder') {
      navigateToFolder(item.id);
    }
  };

  return (
    <div className="h-full flex flex-col bg-background dark:bg-card">
      {/* Toolbar */}
      <div className="flex items-center gap-2 px-2 py-1.5 border-b border-border bg-card/50">
        <div className="flex items-center gap-1">
          <button
            className="p-1.5 rounded hover:bg-accent disabled:opacity-50"
            onClick={() => navigateToFolder(currentFolder?.parentId ?? null)}
            disabled={!currentFolderId}
            data-testid="explorer-btn-back"
          >
            <ChevronLeft className="w-4 h-4 text-foreground" />
          </button>
          <button
            className="p-1.5 rounded hover:bg-accent"
            disabled
            data-testid="explorer-btn-forward"
          >
            <ChevronRight className="w-4 h-4 text-foreground" />
          </button>
          <button
            className="p-1.5 rounded hover:bg-accent"
            onClick={() => navigateToFolder(currentFolder?.parentId ?? null)}
            data-testid="explorer-btn-up"
          >
            <ChevronUp className="w-4 h-4 text-foreground" />
          </button>
          <button
            className="p-1.5 rounded hover:bg-accent"
            data-testid="explorer-btn-refresh"
          >
            <RefreshCw className="w-4 h-4 text-foreground" />
          </button>
        </div>

        {/* Address Bar */}
        <div className="flex-1 flex items-center gap-1 px-2 py-1 rounded bg-card border border-border">
          <HardDrive className="w-4 h-4 text-muted-foreground shrink-0" />
          <span className="text-sm text-foreground">This PC</span>
          {breadcrumbs.map((item, index) => (
            <span key={item.id} className="flex items-center gap-1">
              <ChevronRight className="w-3 h-3 text-muted-foreground" />
              <button
                className="text-sm text-foreground hover:underline"
                onClick={() => navigateToFolder(item.id)}
                data-testid={`explorer-breadcrumb-${item.id}`}
              >
                {item.name}
              </button>
            </span>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-48">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-7 pl-8 pr-2 rounded bg-card border border-border text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            data-testid="explorer-search"
          />
        </div>
      </div>

      {/* Ribbon */}
      <div className="flex items-center gap-4 px-4 py-2 border-b border-border bg-card/30">
        <button className="flex flex-col items-center gap-1 px-2 py-1 rounded hover:bg-accent" data-testid="explorer-btn-new">
          <Plus className="w-5 h-5 text-foreground" />
          <span className="text-xs text-foreground">New</span>
        </button>
        <div className="w-px h-8 bg-border" />
        <button className="flex flex-col items-center gap-1 px-2 py-1 rounded hover:bg-accent" data-testid="explorer-btn-cut">
          <Scissors className="w-4 h-4 text-foreground" />
          <span className="text-xs text-foreground">Cut</span>
        </button>
        <button className="flex flex-col items-center gap-1 px-2 py-1 rounded hover:bg-accent" data-testid="explorer-btn-copy">
          <Copy className="w-4 h-4 text-foreground" />
          <span className="text-xs text-foreground">Copy</span>
        </button>
        <button className="flex flex-col items-center gap-1 px-2 py-1 rounded hover:bg-accent" data-testid="explorer-btn-paste">
          <ClipboardPaste className="w-4 h-4 text-foreground" />
          <span className="text-xs text-foreground">Paste</span>
        </button>
        <button className="flex flex-col items-center gap-1 px-2 py-1 rounded hover:bg-accent" data-testid="explorer-btn-delete">
          <Trash2 className="w-4 h-4 text-foreground" />
          <span className="text-xs text-foreground">Delete</span>
        </button>
        <div className="flex-1" />
        <div className="flex items-center gap-1">
          <button
            className={`p-1.5 rounded ${viewMode === 'grid' ? 'bg-accent' : 'hover:bg-accent'}`}
            onClick={() => setViewMode('grid')}
            data-testid="explorer-view-grid"
          >
            <LayoutGrid className="w-4 h-4 text-foreground" />
          </button>
          <button
            className={`p-1.5 rounded ${viewMode === 'list' ? 'bg-accent' : 'hover:bg-accent'}`}
            onClick={() => setViewMode('list')}
            data-testid="explorer-view-list"
          >
            <List className="w-4 h-4 text-foreground" />
          </button>
          <button className="p-1.5 rounded hover:bg-accent" data-testid="explorer-more">
            <MoreHorizontal className="w-4 h-4 text-foreground" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <div className="w-48 border-r border-border bg-card/30 p-2 overflow-auto shrink-0">
          <div className="text-xs font-semibold text-muted-foreground mb-2 px-2">Quick access</div>
          {quickAccessItems.map(({ id, name, Icon }) => (
            <button
              key={id}
              className={`flex items-center gap-2 w-full px-2 py-1.5 rounded text-sm text-left ${
                currentFolderId === id ? 'bg-accent' : 'hover:bg-accent/50'
              }`}
              onClick={() => navigateToFolder(id)}
              data-testid={`explorer-quick-${id}`}
            >
              <Icon className="w-4 h-4 text-foreground" />
              <span className="text-foreground">{name}</span>
            </button>
          ))}

          <div className="text-xs font-semibold text-muted-foreground mb-2 mt-4 px-2">This PC</div>
          <button
            className={`flex items-center gap-2 w-full px-2 py-1.5 rounded text-sm text-left ${
              !currentFolderId ? 'bg-accent' : 'hover:bg-accent/50'
            }`}
            onClick={() => navigateToFolder(null)}
            data-testid="explorer-this-pc"
          >
            <Monitor className="w-4 h-4 text-foreground" />
            <span className="text-foreground">This PC</span>
          </button>
        </div>

        {/* Files Area */}
        <div className="flex-1 overflow-auto p-4">
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-6 gap-2">
              {filteredFiles.map((item) => {
                const Icon = getFileIcon(item);
                return (
                  <div
                    key={item.id}
                    className="flex flex-col items-center p-3 rounded-md cursor-pointer hover:bg-accent/50"
                    onDoubleClick={() => handleItemDoubleClick(item)}
                    data-testid={`explorer-item-${item.id}`}
                  >
                    <Icon className="w-12 h-12 text-foreground mb-1" strokeWidth={1} />
                    <span className="text-xs text-center text-foreground truncate w-full">
                      {item.name}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="space-y-0.5">
              {filteredFiles.map((item) => {
                const Icon = getFileIcon(item);
                return (
                  <div
                    key={item.id}
                    className="flex items-center gap-3 px-3 py-2 rounded-md cursor-pointer hover:bg-accent/50"
                    onDoubleClick={() => handleItemDoubleClick(item)}
                    data-testid={`explorer-item-${item.id}`}
                  >
                    <Icon className="w-5 h-5 text-foreground" strokeWidth={1.5} />
                    <span className="text-sm text-foreground">{item.name}</span>
                    <span className="text-xs text-muted-foreground ml-auto">
                      {item.type === 'folder' ? 'Folder' : 'File'}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
          
          {filteredFiles.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
              <Folder className="w-16 h-16 mb-4 opacity-50" />
              <p className="text-sm">This folder is empty</p>
            </div>
          )}
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between px-4 py-1 border-t border-border bg-card/50 text-xs text-muted-foreground">
        <span>{filteredFiles.length} items</span>
      </div>
    </div>
  );
}
