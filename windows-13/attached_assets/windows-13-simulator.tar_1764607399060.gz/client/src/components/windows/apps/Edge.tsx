import { useState } from 'react';
import { 
  ChevronLeft, 
  ChevronRight, 
  RefreshCw, 
  Home, 
  Star, 
  Plus, 
  X,
  Search,
  MoreHorizontal,
  Shield,
  Download,
  User,
  Settings,
  Globe,
  ArrowUp
} from 'lucide-react';

interface Tab {
  id: string;
  title: string;
  url: string;
  isSearchResult?: boolean;
  favicon?: string;
}

const defaultTabs: Tab[] = [
  { id: 'tab-1', title: 'New Tab', url: 'edge://newtab' },
];

const quickLinks = [
  { name: 'Microsoft', url: 'https://microsoft.com', color: 'bg-emerald-500' },
  { name: 'Outlook', url: 'https://outlook.com', color: 'bg-blue-500' },
  { name: 'Office', url: 'https://office.com', color: 'bg-orange-500' },
  { name: 'LinkedIn', url: 'https://linkedin.com', color: 'bg-sky-600' },
  { name: 'MSN', url: 'https://msn.com', color: 'bg-rose-500' },
  { name: 'GitHub', url: 'https://github.com', color: 'bg-slate-700' },
];

export function Edge() {
  const [tabs, setTabs] = useState<Tab[]>(defaultTabs);
  const [activeTabId, setActiveTabId] = useState('tab-1');
  const [addressBarValue, setAddressBarValue] = useState('');
  const [isAddressBarFocused, setIsAddressBarFocused] = useState(false);
  const [iframeUrl, setIframeUrl] = useState('');

  const activeTab = tabs.find(t => t.id === activeTabId);

  const addTab = () => {
    const newTab: Tab = {
      id: `tab-${Date.now()}`,
      title: 'New Tab',
      url: 'edge://newtab',
    };
    setTabs([...tabs, newTab]);
    setActiveTabId(newTab.id);
    setAddressBarValue('');
    setIframeUrl('');
  };

  const closeTab = (tabId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) return;
    
    const newTabs = tabs.filter(t => t.id !== tabId);
    setTabs(newTabs);
    
    if (activeTabId === tabId) {
      setActiveTabId(newTabs[newTabs.length - 1].id);
    }
  };

  const handleNavigate = (url: string) => {
    let fullUrl = url;
    let title = url;
    let isSearchResult = false;

    if (!url.startsWith('http') && !url.startsWith('edge://')) {
      if (url.includes('.')) {
        // It's a URL
        fullUrl = `https://${url}`;
        title = url.replace('https://', '').replace('www.', '').split('/')[0];
      } else {
        // It's a search query - use Bing search
        fullUrl = `https://www.bing.com/search?q=${encodeURIComponent(url)}`;
        title = url;
        isSearchResult = true;
      }
    } else if (url.startsWith('http')) {
      title = url.replace('https://', '').replace('http://', '').replace('www.', '').split('/')[0];
    }

    // Update tab with new URL
    setTabs(tabs.map(t => 
      t.id === activeTabId 
        ? { ...t, url: fullUrl, title, isSearchResult }
        : t
    ));
    setAddressBarValue(fullUrl);
    setIframeUrl(fullUrl);
  };

  const handleAddressBarSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (addressBarValue.trim()) {
      handleNavigate(addressBarValue);
    }
    setIsAddressBarFocused(false);
  };

  return (
    <div className="h-full flex flex-col bg-background dark:bg-card">
      {/* Tab Bar */}
      <div className="flex items-center h-9 bg-card/80 px-2 gap-1">
        {tabs.map((tab) => (
          <div
            key={tab.id}
            className={`flex items-center gap-2 h-7 px-3 rounded-t-md cursor-pointer max-w-[200px] min-w-[120px] ${
              activeTabId === tab.id 
                ? 'bg-background dark:bg-card' 
                : 'hover:bg-accent/50'
            }`}
            onClick={() => {
              setActiveTabId(tab.id);
              const clickedTab = tabs.find(t => t.id === tab.id);
              setAddressBarValue(clickedTab?.url === 'edge://newtab' ? '' : clickedTab?.url || '');
              setIframeUrl(clickedTab?.url === 'edge://newtab' ? '' : clickedTab?.url || '');
            }}
            data-testid={`edge-tab-${tab.id}`}
          >
            <Globe className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
            <span className="text-xs text-foreground truncate flex-1">{tab.title}</span>
            {tabs.length > 1 && (
              <button
                className="p-0.5 rounded hover:bg-accent shrink-0"
                onClick={(e) => closeTab(tab.id, e)}
                data-testid={`edge-close-tab-${tab.id}`}
              >
                <X className="w-3 h-3 text-muted-foreground" />
              </button>
            )}
          </div>
        ))}
        <button
          className="w-7 h-7 flex items-center justify-center rounded hover:bg-accent"
          onClick={addTab}
          data-testid="edge-add-tab"
        >
          <Plus className="w-4 h-4 text-foreground" />
        </button>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-2 h-10 px-2 border-b border-border bg-background dark:bg-card">
        <button className="p-1.5 rounded hover:bg-accent" data-testid="edge-back">
          <ChevronLeft className="w-4 h-4 text-foreground" />
        </button>
        <button className="p-1.5 rounded hover:bg-accent" data-testid="edge-forward">
          <ChevronRight className="w-4 h-4 text-foreground" />
        </button>
        <button className="p-1.5 rounded hover:bg-accent" data-testid="edge-refresh">
          <RefreshCw className="w-4 h-4 text-foreground" />
        </button>
        <button 
          className="p-1.5 rounded hover:bg-accent" 
          data-testid="edge-home"
          onClick={() => {
            setTabs(tabs.map(t => 
              t.id === activeTabId 
                ? { ...t, url: 'edge://newtab', title: 'New Tab', isSearchResult: false }
                : t
            ));
            setAddressBarValue('');
            setIframeUrl('');
          }}
        >
          <Home className="w-4 h-4 text-foreground" />
        </button>

        {/* Address Bar */}
        <form 
          className="flex-1 relative"
          onSubmit={handleAddressBarSubmit}
        >
          <div className={`flex items-center h-8 rounded-full border ${
            isAddressBarFocused ? 'border-primary ring-1 ring-primary' : 'border-border'
          } bg-card px-3 gap-2`}>
            {!isAddressBarFocused && activeTab?.url !== 'edge://newtab' && (
              <Shield className="w-4 h-4 text-muted-foreground shrink-0" />
            )}
            {isAddressBarFocused && (
              <Search className="w-4 h-4 text-muted-foreground shrink-0" />
            )}
            <input
              type="text"
              value={addressBarValue}
              onChange={(e) => setAddressBarValue(e.target.value)}
              onFocus={() => setIsAddressBarFocused(true)}
              onBlur={() => setIsAddressBarFocused(false)}
              placeholder="Search or enter web address"
              className="flex-1 bg-transparent text-sm text-foreground focus:outline-none"
              data-testid="edge-address-bar"
            />
          </div>
        </form>

        <button className="p-1.5 rounded hover:bg-accent" data-testid="edge-favorite">
          <Star className="w-4 h-4 text-foreground" />
        </button>
        <button className="p-1.5 rounded hover:bg-accent" data-testid="edge-downloads">
          <Download className="w-4 h-4 text-foreground" />
        </button>
        <button className="p-1.5 rounded hover:bg-accent" data-testid="edge-profile">
          <User className="w-4 h-4 text-foreground" />
        </button>
        <button className="p-1.5 rounded hover:bg-accent" data-testid="edge-settings">
          <MoreHorizontal className="w-4 h-4 text-foreground" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto bg-background dark:bg-card">
        {activeTab?.url === 'edge://newtab' ? (
          <div className="flex flex-col items-center justify-center h-full p-8">
            {/* Search Box */}
            <div className="w-full max-w-xl mb-12">
              <h1 className="text-3xl font-light text-center text-foreground mb-6">
                Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}
              </h1>
              <form 
                className="relative"
                onSubmit={(e) => {
                  e.preventDefault();
                  handleNavigate(addressBarValue);
                }}
              >
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  value={addressBarValue}
                  onChange={(e) => setAddressBarValue(e.target.value)}
                  placeholder="Search the web"
                  className="w-full h-12 pl-12 pr-4 rounded-full bg-card border border-border text-base focus:outline-none focus:ring-2 focus:ring-primary"
                  data-testid="edge-search-box"
                />
              </form>
            </div>

            {/* Quick Links */}
            <div className="grid grid-cols-6 gap-4 max-w-2xl">
              {quickLinks.map(({ name, url, color }) => (
                <button
                  key={name}
                  className="flex flex-col items-center gap-2 p-4 rounded-lg hover:bg-accent transition-colors"
                  onClick={() => handleNavigate(url)}
                  data-testid={`edge-quicklink-${name.toLowerCase()}`}
                >
                  <div className={`w-10 h-10 ${color} rounded-lg flex items-center justify-center`}>
                    <span className="text-white font-semibold text-lg">
                      {name[0]}
                    </span>
                  </div>
                  <span className="text-xs text-foreground">{name}</span>
                </button>
              ))}
            </div>
          </div>
        ) : iframeUrl ? (
          <iframe 
            src={iframeUrl}
            className="w-full h-full border-0"
            sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
            title="Browser content"
            data-testid="edge-iframe"
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center text-muted-foreground">
            <Globe className="w-20 h-20 mx-auto mb-4 opacity-30" />
            <p className="text-lg font-medium text-foreground mb-2">Ready to Browse</p>
            <p className="text-sm mb-4">Enter a search query or URL in the address bar</p>
            <p className="text-xs opacity-75">
              Type anything and press Enter to search or navigate
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
