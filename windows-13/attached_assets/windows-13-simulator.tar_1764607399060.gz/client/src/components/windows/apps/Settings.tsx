import { useWindowsStore } from '@/lib/windows-store';
import { useState } from 'react';
import { 
  Monitor, 
  Wifi, 
  Bluetooth, 
  Palette, 
  User, 
  Bell, 
  Shield, 
  Clock, 
  Accessibility, 
  Lock, 
  Settings as SettingsIcon,
  ChevronRight,
  Search,
  Moon,
  Sun,
  Check
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';

const settingsCategories = [
  { id: 'system', Icon: Monitor, name: 'System', description: 'Display, sound, notifications, power' },
  { id: 'bluetooth', Icon: Bluetooth, name: 'Bluetooth & devices', description: 'Bluetooth, printers, mouse' },
  { id: 'network', Icon: Wifi, name: 'Network & internet', description: 'Wi-Fi, ethernet, VPN' },
  { id: 'personalization', Icon: Palette, name: 'Personalization', description: 'Background, colors, lock screen' },
  { id: 'accounts', Icon: User, name: 'Accounts', description: 'Your accounts, email, sync' },
  { id: 'time', Icon: Clock, name: 'Time & language', description: 'Speech, region, date' },
  { id: 'accessibility', Icon: Accessibility, name: 'Accessibility', description: 'Narrator, magnifier, contrast' },
  { id: 'privacy', Icon: Lock, name: 'Privacy & security', description: 'Location, camera, microphone' },
  { id: 'update', Icon: Shield, name: 'Windows Update', description: 'Updates, security' },
];

const wallpapers = [
  { id: 'bloom-blue', color: 'from-blue-600 via-indigo-500 to-purple-600' },
  { id: 'bloom-pink', color: 'from-pink-500 via-rose-400 to-orange-400' },
  { id: 'bloom-green', color: 'from-emerald-500 via-teal-400 to-cyan-500' },
  { id: 'bloom-dark', color: 'from-slate-900 via-slate-800 to-slate-700' },
];

export function Settings() {
  const { darkMode, toggleDarkMode, userName, setUserName } = useWindowsStore();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const renderMainContent = () => {
    if (!activeCategory) {
      return (
        <div className="p-6">
          <h1 className="text-2xl font-light text-foreground mb-6">Settings</h1>
          
          <div className="grid gap-2">
            {settingsCategories.map(({ id, Icon, name, description }) => (
              <button
                key={id}
                className="flex items-center gap-4 p-4 rounded-lg hover:bg-accent text-left"
                onClick={() => setActiveCategory(id)}
                data-testid={`settings-category-${id}`}
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-foreground">{name}</div>
                  <div className="text-xs text-muted-foreground">{description}</div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>
      );
    }

    if (activeCategory === 'personalization') {
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button
              className="p-2 rounded-md hover:bg-accent"
              onClick={() => setActiveCategory(null)}
              data-testid="settings-back"
            >
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">Personalization</h1>
          </div>

          {/* Theme */}
          <div className="mb-8">
            <h2 className="text-sm font-semibold text-foreground mb-4">Choose your mode</h2>
            <div className="flex gap-4">
              <button
                className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-colors ${
                  !darkMode ? 'border-primary bg-primary/5' : 'border-border hover:border-muted-foreground'
                }`}
                onClick={() => darkMode && toggleDarkMode()}
                data-testid="settings-theme-light"
              >
                <div className="w-16 h-12 rounded bg-white border border-border flex items-center justify-center">
                  <Sun className="w-6 h-6 text-amber-500" />
                </div>
                <span className="text-sm text-foreground">Light</span>
                {!darkMode && <Check className="w-4 h-4 text-primary" />}
              </button>
              <button
                className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-colors ${
                  darkMode ? 'border-primary bg-primary/5' : 'border-border hover:border-muted-foreground'
                }`}
                onClick={() => !darkMode && toggleDarkMode()}
                data-testid="settings-theme-dark"
              >
                <div className="w-16 h-12 rounded bg-slate-800 border border-slate-600 flex items-center justify-center">
                  <Moon className="w-6 h-6 text-slate-300" />
                </div>
                <span className="text-sm text-foreground">Dark</span>
                {darkMode && <Check className="w-4 h-4 text-primary" />}
              </button>
            </div>
          </div>

          {/* Background */}
          <div className="mb-8">
            <h2 className="text-sm font-semibold text-foreground mb-4">Background</h2>
            <div className="grid grid-cols-4 gap-4">
              {wallpapers.map(({ id, color }) => (
                <button
                  key={id}
                  className={`aspect-video rounded-lg bg-gradient-to-br ${color} border-2 border-transparent hover:border-primary transition-colors`}
                  data-testid={`settings-wallpaper-${id}`}
                />
              ))}
            </div>
          </div>

          {/* Accent Color */}
          <div>
            <h2 className="text-sm font-semibold text-foreground mb-4">Accent color</h2>
            <div className="flex gap-2">
              {['#0078d4', '#0099bc', '#7a7574', '#107c10', '#ff8c00', '#e81123', '#b146c2'].map((color) => (
                <button
                  key={color}
                  className="w-8 h-8 rounded-full border-2 border-transparent hover:border-white/50 transition-colors"
                  style={{ backgroundColor: color }}
                  data-testid={`settings-accent-${color.replace('#', '')}`}
                />
              ))}
            </div>
          </div>
        </div>
      );
    }

    if (activeCategory === 'system') {
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button
              className="p-2 rounded-md hover:bg-accent"
              onClick={() => setActiveCategory(null)}
              data-testid="settings-back"
            >
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">System</h1>
          </div>

          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-card">
              <div className="flex items-center justify-between mb-3">
                <div className="text-sm font-medium text-foreground">Display brightness</div>
                <span className="text-xs text-muted-foreground">75%</span>
              </div>
              <input type="range" min="0" max="100" defaultValue="75" className="w-full" />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div>
                <div className="text-sm font-medium text-foreground">Night light</div>
                <div className="text-xs text-muted-foreground">Reduce blue light at night</div>
              </div>
              <Switch defaultChecked={false} data-testid="settings-night-light" />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div>
                <div className="text-sm font-medium text-foreground">Notifications</div>
                <div className="text-xs text-muted-foreground">Alerts from apps and system</div>
              </div>
              <Switch defaultChecked={true} data-testid="settings-notifications-toggle" />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div>
                <div className="text-sm font-medium text-foreground">Focus assist</div>
                <div className="text-xs text-muted-foreground">Reduce distractions</div>
              </div>
              <Switch defaultChecked={false} data-testid="settings-focus-toggle" />
            </div>
            <div className="p-4 rounded-lg bg-card">
              <div className="text-sm font-medium text-foreground mb-2">Display resolution</div>
              <select className="w-full h-8 rounded border border-border bg-background text-sm text-foreground">
                <option>1920 x 1080 (Recommended)</option>
                <option>1600 x 900</option>
                <option>1366 x 768</option>
                <option>2560 x 1440</option>
              </select>
            </div>
          </div>
        </div>
      );
    }

    if (activeCategory === 'network') {
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button className="p-2 rounded-md hover:bg-accent" onClick={() => setActiveCategory(null)}>
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">Network & internet</h1>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">Wi-Fi</div></div>
              <Switch defaultChecked={true} />
            </div>
            <div className="p-4 rounded-lg bg-card">
              <div className="text-sm font-medium text-foreground mb-2">Connected networks</div>
              <div className="text-xs text-muted-foreground bg-background p-2 rounded">Home Network (Connected)</div>
            </div>
          </div>
        </div>
      );
    }

    if (activeCategory === 'bluetooth') {
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button className="p-2 rounded-md hover:bg-accent" onClick={() => setActiveCategory(null)}>
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">Bluetooth & devices</h1>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">Bluetooth</div></div>
              <Switch defaultChecked={true} />
            </div>
            <div className="p-4 rounded-lg bg-card">
              <div className="text-sm font-medium text-foreground mb-2">Connected devices</div>
              <div className="text-xs text-muted-foreground">No devices connected</div>
            </div>
          </div>
        </div>
      );
    }

    if (activeCategory === 'accounts') {
      const handlePowerAction = (action: 'sleep' | 'restart' | 'shutdown') => {
        if (action === 'sleep') {
          alert('Entering sleep mode...');
        } else if (action === 'restart') {
          alert('Restarting...');
          window.location.reload();
        } else if (action === 'shutdown') {
          alert('Powering off...');
          window.close();
        }
      };
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button className="p-2 rounded-md hover:bg-accent" onClick={() => setActiveCategory(null)}>
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">Accounts</h1>
          </div>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-card">
              <div className="text-sm font-medium text-foreground mb-4">Your account</div>
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                  <User className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-foreground">{userName}</div>
                  <div className="text-xs text-muted-foreground">Local account</div>
                </div>
              </div>
              <div className="mb-4">
                <div className="text-sm font-medium text-foreground mb-2">Edit username</div>
                <input 
                  type="text" 
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  className="w-full h-10 px-3 rounded border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="Enter username"
                />
              </div>
              <div>
                <div className="text-sm font-medium text-foreground mb-3">Power options</div>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handlePowerAction('sleep')}
                    className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 hover:bg-blue-500/20 text-sm font-medium text-foreground transition-colors"
                    data-testid="button-sleep"
                  >
                    Sleep
                  </button>
                  <button
                    onClick={() => handlePowerAction('restart')}
                    className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 text-sm font-medium text-foreground transition-colors"
                    data-testid="button-restart"
                  >
                    Restart
                  </button>
                  <button
                    onClick={() => handlePowerAction('shutdown')}
                    className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 hover:bg-red-500/20 text-sm font-medium text-foreground transition-colors"
                    data-testid="button-shutdown"
                  >
                    Power Off
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (activeCategory === 'time') {
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button className="p-2 rounded-md hover:bg-accent" onClick={() => setActiveCategory(null)}>
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">Time & language</h1>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">Set time automatically</div></div>
              <Switch defaultChecked={true} />
            </div>
            <div className="p-4 rounded-lg bg-card">
              <div className="text-sm font-medium text-foreground mb-2">Time zone</div>
              <select className="w-full h-8 rounded border border-border bg-background text-sm text-foreground">
                <option>UTC-05:00 (Eastern Time)</option>
                <option>UTC-06:00 (Central Time)</option>
                <option>UTC-07:00 (Mountain Time)</option>
                <option>UTC-08:00 (Pacific Time)</option>
              </select>
            </div>
            <div className="p-4 rounded-lg bg-card">
              <div className="text-sm font-medium text-foreground mb-2">Language</div>
              <select className="w-full h-8 rounded border border-border bg-background text-sm text-foreground">
                <option>English (United States)</option>
                <option>Spanish (Spain)</option>
                <option>French (France)</option>
                <option>German (Germany)</option>
              </select>
            </div>
          </div>
        </div>
      );
    }

    if (activeCategory === 'accessibility') {
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button className="p-2 rounded-md hover:bg-accent" onClick={() => setActiveCategory(null)}>
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">Accessibility</h1>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">Narrator</div></div>
              <Switch defaultChecked={false} />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">Magnifier</div></div>
              <Switch defaultChecked={false} />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">High contrast</div></div>
              <Switch defaultChecked={false} />
            </div>
          </div>
        </div>
      );
    }

    if (activeCategory === 'privacy') {
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button className="p-2 rounded-md hover:bg-accent" onClick={() => setActiveCategory(null)}>
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">Privacy & security</h1>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">Location</div></div>
              <Switch defaultChecked={true} />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">Camera</div></div>
              <Switch defaultChecked={false} />
            </div>
            <div className="flex items-center justify-between p-4 rounded-lg bg-card">
              <div><div className="text-sm font-medium text-foreground">Microphone</div></div>
              <Switch defaultChecked={false} />
            </div>
          </div>
        </div>
      );
    }

    if (activeCategory === 'update') {
      return (
        <div className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <button className="p-2 rounded-md hover:bg-accent" onClick={() => setActiveCategory(null)}>
              <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
            </button>
            <h1 className="text-2xl font-light text-foreground">Windows Update</h1>
          </div>
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/30">
              <div className="text-sm font-medium text-green-700 dark:text-green-400">Your device is up to date</div>
              <div className="text-xs text-green-600 dark:text-green-300 mt-1">Last checked: Today at 10:30 AM</div>
            </div>
            <button className="w-full py-2 px-4 rounded-lg bg-primary text-primary-foreground hover:opacity-90 font-medium text-sm">
              Check for updates
            </button>
          </div>
        </div>
      );
    }

    // Default view for other categories
    return (
      <div className="p-6">
        <div className="flex items-center gap-4 mb-6">
          <button className="p-2 rounded-md hover:bg-accent" onClick={() => setActiveCategory(null)}>
            <ChevronRight className="w-4 h-4 text-foreground rotate-180" />
          </button>
          <h1 className="text-2xl font-light text-foreground">
            {settingsCategories.find(c => c.id === activeCategory)?.name}
          </h1>
        </div>
        <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
          <SettingsIcon className="w-16 h-16 mb-4 opacity-50" />
          <p className="text-sm">Settings configured</p>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex bg-background dark:bg-card overflow-hidden">
      {/* Sidebar */}
      <div className="w-64 border-r border-border bg-card/50 p-4 shrink-0">
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Find a setting"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-9 pl-10 pr-4 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-1 focus:ring-primary"
            data-testid="settings-search"
          />
        </div>

        <div className="space-y-0.5">
          {settingsCategories.map(({ id, Icon, name }) => (
            <button
              key={id}
              className={`flex items-center gap-3 w-full px-3 py-2 rounded-md text-sm text-left transition-colors ${
                activeCategory === id ? 'bg-accent' : 'hover:bg-accent/50'
              }`}
              onClick={() => setActiveCategory(id)}
              data-testid={`settings-nav-${id}`}
            >
              <Icon className="w-4 h-4 text-foreground" />
              <span className="text-foreground">{name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {renderMainContent()}
      </div>
    </div>
  );
}
