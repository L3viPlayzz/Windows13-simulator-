import { ReactNode, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';

interface OverlayPortalProps {
  children: ReactNode;
  zIndex: number;
}

/**
 * Portal component for rendering overlays outside main DOM.
 * Fixes z-index chaos and keeps overlays separated from layout.
 */
export function OverlayPortal({ children, zIndex }: OverlayPortalProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!containerRef.current) {
      const container = document.createElement('div');
      container.style.position = 'fixed';
      container.style.top = '0';
      container.style.left = '0';
      container.style.width = '100%';
      container.style.height = '100%';
      container.style.zIndex = zIndex.toString();
      container.style.pointerEvents = 'none';
      document.body.appendChild(container);
      containerRef.current = container;
    } else {
      containerRef.current.style.zIndex = zIndex.toString();
    }

    return () => {
      if (containerRef.current && containerRef.current.parentNode) {
        containerRef.current.parentNode.removeChild(containerRef.current);
        containerRef.current = null;
      }
    };
  }, [zIndex]);

  if (!containerRef.current) return null;

  return createPortal(
    <div style={{ pointerEvents: 'auto' }}>
      {children}
    </div>,
    containerRef.current
  );
}
