import { useWindowsStore } from '@/lib/windows-store';
import { 
  Search, 
  LayoutGrid, 
  Folder, 
  Globe, 
  MessageSquare,
  Wifi,
  Volume2,
  Battery,
  ChevronUp,
  User
} from 'lucide-react';
import { useEffect, useState } from 'react';

export function Taskbar() {
  const { 
    windows, 
    activeWindowId,
    toggleStartMenu, 
    toggleSearch,
    toggleActionCenter,
    toggleWidgets,
    toggleNotificationPanel,
    toggleAccountMenu,
    focusWindow,
    openWindow,
    minimizeWindow,
  } = useWindowsStore();

  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const time = currentTime.toLocaleTimeString('en-US', { 
    hour: 'numeric', 
    minute: '2-digit',
    hour12: true 
  });
  const date = currentTime.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    year: 'numeric' 
  });

  const pinnedApps = [
    { id: 'explorer', Icon: Folder, name: 'File Explorer' },
    { id: 'edge', Icon: Globe, name: 'Microsoft Edge' },
  ];

  const openApps = windows.filter(w => !w.isMinimized);

  const handleTaskbarClick = (windowId: string, isMinimized: boolean) => {
    if (isMinimized || activeWindowId !== windowId) {
      focusWindow(windowId);
    } else {
      minimizeWindow(windowId);
    }
  };

  return (
    <div 
      className="fixed bottom-0 left-0 right-0 h-14 win-taskbar flex items-center justify-between px-4 z-50 rounded-3xl" style={{bottom: "8px", left: "50%", transform: "translateX(-50%)", width: "95%"}}
      data-testid="taskbar"
    >
      {/* Left section - Widgets */}
      <div className="flex items-center gap-1">
        <button
          className="taskbar-icon text-foreground hover:bg-primary/10 rounded p-2 transition-colors"
          onClick={toggleWidgets}
          data-testid="button-widgets"
          title="Widgets"
        >
          <LayoutGrid className="w-5 h-5" />
        </button>
      </div>

      {/* Center section - App icons */}
      <div className="flex items-center gap-1">
        {/* Start Button */}
        <button
          className="taskbar-icon text-foreground hover:bg-primary/10 rounded p-2 transition-colors"
          onClick={toggleStartMenu}
          data-testid="button-start"
          title="Start"
        >
          <svg 
            viewBox="0 0 24 24" 
            className="w-5 h-5 fill-current"
          >
            <path d="M3 3h8v8H3V3zm10 0h8v8h-8V3zM3 13h8v8H3v-8zm10 0h8v8h-8v-8z"/>
          </svg>
        </button>

        {/* Search */}
        <button
          className="taskbar-icon text-foreground hover:bg-primary/10 rounded p-2 transition-colors"
          onClick={toggleSearch}
          data-testid="button-search"
          title="Search"
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Pinned Apps */}
        {pinnedApps.map(({ id, Icon, name }) => {
          const appWindow = windows.find(w => w.appId === id);
          const isActive = appWindow && !appWindow.isMinimized;
          
          return (
            <button
              key={id}
              className={`taskbar-icon text-foreground hover:bg-primary/10 rounded p-2 transition-colors ${isActive ? 'active bg-primary/15' : ''}`}
              onClick={() => {
                if (appWindow) {
                  handleTaskbarClick(appWindow.id, appWindow.isMinimized);
                } else {
                  openWindow(id, name, id === 'explorer' ? 900 : 1200, id === 'explorer' ? 600 : 800);
                }
              }}
              data-testid={`taskbar-icon-${id}`}
              title={name}
            >
              <Icon className="w-5 h-5" />
            </button>
          );
        })}

        {/* Open Windows */}
        {windows
          .filter(w => !pinnedApps.some(p => p.id === w.appId))
          .map(window => (
            <button
              key={window.id}
              className={`taskbar-icon text-foreground hover:bg-primary/10 rounded p-2 transition-colors ${!window.isMinimized ? 'active bg-primary/15' : ''}`}
              onClick={() => handleTaskbarClick(window.id, window.isMinimized)}
              data-testid={`taskbar-window-${window.id}`}
              title={window.title}
            >
              <MessageSquare className="w-5 h-5" />
            </button>
          ))}
      </div>

      {/* Right section - System tray */}
      <div className="flex items-center gap-1">
        <button 
          className="taskbar-icon text-foreground hover:bg-primary/10 rounded p-2 transition-colors"
          onClick={toggleNotificationPanel}
          data-testid="button-quick-settings"
          title="Quick Settings"
        >
          <ChevronUp className="w-4 h-4" />
        </button>

        <button
          className="flex items-center gap-1 px-3 py-2 rounded hover:bg-primary/10 text-foreground text-xs transition-colors"
          onClick={toggleActionCenter}
          data-testid="button-action-center"
          title="Action Center"
        >
          <Wifi className="w-3.5 h-3.5" />
          <Volume2 className="w-3.5 h-3.5" />
          <Battery className="w-3.5 h-3.5" />
        </button>

        <button
          className="flex flex-col items-end px-3 py-1 rounded hover:bg-primary/10 text-foreground text-xs transition-colors"
          onClick={toggleActionCenter}
          data-testid="button-time"
          title="Date and Time"
        >
          <span>{time}</span>
          <span className="text-xs opacity-75">{date}</span>
        </button>

        <button
          className="taskbar-icon text-foreground hover:bg-primary/10 rounded p-2 transition-colors"
          onClick={toggleAccountMenu}
          data-testid="button-account"
          title="Account"
        >
          <User className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
