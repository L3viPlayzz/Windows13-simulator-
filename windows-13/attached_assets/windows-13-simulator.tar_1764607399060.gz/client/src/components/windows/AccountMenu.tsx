import { useWindowsStore } from '@/lib/windows-store';
import { Power, LogOut, Moon, Sun, User, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';

export function AccountMenu() {
  const { accountMenuOpen, closeAccountMenu, userName, darkMode, toggleDarkMode, lockSystem, powerState, handleSleep, handleRestart, handleShutdown, setPowerState, setShowingStartup } = useWindowsStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(userName);

  const handleSaveName = () => {
    if (editName.trim()) {
      useWindowsStore.setState({ userName: editName });
      setIsEditing(false);
    }
  };

  const onSleep = () => {
    closeAccountMenu();
    handleSleep();
  };

  const onRestart = () => {
    closeAccountMenu();
    setShowingStartup(true);
    handleRestart();
  };

  const onShutdown = () => {
    closeAccountMenu();
    handleShutdown();
  };

  return (
    <>
      <AnimatePresence>
        {powerState === 'sleeping' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.6, ease: "easeInOut" }} className="fixed inset-0 bg-card z-[999] flex items-center justify-center">
            <motion.div animate={{ opacity: [1, 0.3, 1], scale: [1, 0.98, 1] }} transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }} className="text-foreground text-3xl font-light tracking-wide">
              Sleep Mode
            </motion.div>
          </motion.div>
        )}
        {powerState === 'restarting' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, ease: "easeInOut" }} className="fixed inset-0 bg-gradient-to-b from-slate-900 to-black z-[999] flex flex-col items-center justify-center gap-8">
            <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.7, ease: "easeOut" }}>
              <svg className="w-24 h-24 text-cyan-400" viewBox="0 0 100 100" fill="currentColor">
                <rect x="10" y="10" width="35" height="35" fill="currentColor" />
                <rect x="55" y="10" width="35" height="35" fill="currentColor" />
                <rect x="10" y="55" width="35" height="35" fill="currentColor" />
                <rect x="55" y="55" width="35" height="35" fill="currentColor" />
              </svg>
            </motion.div>
            <div className="flex gap-2">
              {[0, 1, 2, 3].map((i) => (
                <motion.div key={i} className="w-2 h-2 bg-cyan-400 rounded-full" animate={{ opacity: [0.4, 1, 0.4], scale: [1, 1.3, 1] }} transition={{ duration: 2, delay: i * 0.2, repeat: Infinity, ease: "easeInOut" }} />
              ))}
            </div>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3, duration: 0.6 }} className="text-cyan-400 text-lg font-light">Restarting...</motion.p>
          </motion.div>
        )}
        {powerState === 'shutdown' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.5, ease: "easeInOut" }} onClick={() => setPowerState('normal')} onKeyDown={() => setPowerState('normal')} className="fixed inset-0 bg-black z-[999] flex flex-col items-center justify-center gap-8 cursor-pointer" tabIndex={0}>
            <motion.div initial={{ scale: 1.1, opacity: 0 }} animate={{ scale: 0.85, opacity: 0 }} transition={{ duration: 4.5, delay: 0.3, ease: "easeInOut" }} className="drop-shadow-lg">
              <svg className="w-24 h-24 text-cyan-400" viewBox="0 0 100 100" fill="currentColor">
                <rect x="10" y="10" width="35" height="35" fill="currentColor" />
                <rect x="55" y="10" width="35" height="35" fill="currentColor" />
                <rect x="10" y="55" width="35" height="35" fill="currentColor" />
                <rect x="55" y="55" width="35" height="35" fill="currentColor" />
              </svg>
            </motion.div>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }} className="text-cyan-400 text-lg font-light">
              Shutting down...
            </motion.p>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: [0, 1, 1, 0] }} transition={{ duration: 5, delay: 2, ease: "easeInOut" }} className="text-white text-sm font-light absolute bottom-8">
              Press any key to restart
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {accountMenuOpen && powerState === 'normal' && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0" onClick={closeAccountMenu} data-testid="account-menu-backdrop" />
            <motion.div initial={{ opacity: 0, y: 10, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 10, scale: 0.95 }} transition={{ duration: 0.15 }} className="fixed bottom-12 right-4 w-64 bg-card rounded-lg border border-border shadow-lg overflow-hidden z-50" data-testid="account-menu">
              <div className="p-4 border-b border-border bg-muted/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    {isEditing ? (
                      <input type="text" value={editName} onChange={(e) => setEditName(e.target.value)} onBlur={handleSaveName} onKeyDown={(e) => {if (e.key === 'Enter') handleSaveName(); if (e.key === 'Escape') setIsEditing(false);}} className="w-full text-sm font-semibold bg-background border border-border rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-primary" autoFocus />
                    ) : (
                      <button onClick={() => setIsEditing(true)} className="text-sm font-semibold text-foreground hover:text-primary transition-colors truncate block text-left w-full" title={userName}>
                        {userName}
                      </button>
                    )}
                  </div>
                </div>
              </div>
              <button onClick={() => { toggleDarkMode(); closeAccountMenu(); }} className="w-full px-4 py-2 flex items-center gap-3 hover:bg-accent transition-colors text-sm">
                {darkMode ? (<><Sun className="w-4 h-4" /><span>Light mode</span></>) : (<><Moon className="w-4 h-4" /><span>Dark mode</span></>)}
              </button>
              <div className="h-px bg-border" />
              <button onClick={() => lockSystem()} className="w-full px-4 py-2 flex items-center gap-3 hover:bg-accent transition-colors text-sm" data-testid="button-lock">
                <Lock className="w-4 h-4" />
                <span>Lock</span>
              </button>
              <div className="h-px bg-border" />
              <div className="p-2 space-y-1" data-testid="power-options">
                <button onClick={onSleep} className="w-full px-3 py-2 flex items-center gap-3 hover:bg-accent rounded text-sm transition-colors text-left" data-testid="button-sleep">
                  <Power className="w-4 h-4" />
                  <span>Sleep</span>
                </button>
                <button onClick={onRestart} className="w-full px-3 py-2 flex items-center gap-3 hover:bg-accent rounded text-sm transition-colors text-left" data-testid="button-restart">
                  <Power className="w-4 h-4" />
                  <span>Restart</span>
                </button>
                <button onClick={onShutdown} className="w-full px-3 py-2 flex items-center gap-3 hover:bg-destructive/20 text-destructive hover:bg-destructive/30 rounded text-sm transition-colors text-left" data-testid="button-shutdown">
                  <LogOut className="w-4 h-4" />
                  <span>Power off</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
