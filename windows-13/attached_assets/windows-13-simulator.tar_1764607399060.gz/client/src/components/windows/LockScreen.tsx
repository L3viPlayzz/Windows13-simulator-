import { useWindowsStore } from '@/lib/windows-store';
import { motion } from 'framer-motion';
import { useState } from 'react';
import { Lock } from 'lucide-react';

export function LockScreen() {
  const { isLocked, unlockSystem, userName } = useWindowsStore();
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleUnlock = () => {
    if (unlockSystem(password)) {
      setPassword('');
      setError(false);
    } else {
      setError(true);
      setPassword('');
      setTimeout(() => setError(false), 2000);
    }
  };

  if (!isLocked) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-gradient-to-br from-blue-100 to-blue-50 dark:from-slate-950 dark:to-slate-900 z-[9999] flex items-center justify-center"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex flex-col items-center gap-8 text-primary"
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Lock className="w-24 h-24 text-primary" />
        </motion.div>

        <div className="text-center">
          <p className="text-2xl font-light mb-2">Locked</p>
          <p className="text-primary/80">{userName}</p>
        </div>

        <div className="w-80">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleUnlock();
            }}
            placeholder="Enter password"
            className="w-full px-4 py-3 rounded-lg bg-primary/10 text-primary placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 backdrop-blur-sm"
            autoFocus
            data-testid="input-lock-password"
          />
        </div>

        {error && (
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-destructive text-sm"
          >
            Incorrect password
          </motion.p>
        )}

        <button
          onClick={handleUnlock}
          className="px-8 py-2 bg-primary text-primary rounded-lg font-semibold hover:bg-primary/90 transition-all"
          data-testid="button-unlock"
        >
          Unlock
        </button>
      </motion.div>
    </motion.div>
  );
}
