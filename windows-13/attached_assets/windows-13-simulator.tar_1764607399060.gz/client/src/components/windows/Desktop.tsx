import { useWindowsStore } from '@/lib/windows-store';

// Modern Blue Icons for Light Theme
const CalculatorIcon = () => (
  <svg viewBox="0 0 24 24" className="w-10 h-10">
    <defs>
      <linearGradient id="calcGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: '#065FD4', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: '#167AC6', stopOpacity: 1}} />
      </linearGradient>
    </defs>
    <rect x="1" y="1" width="22" height="22" rx="3" fill="url(#calcGrad)"/>
    <g fill="#FFFFFF" opacity="0.9">
      <rect x="3" y="3" width="18" height="4" rx="0.5"/>
      <rect x="3" y="8" width="4" height="4" rx="0.5"/>
      <rect x="8" y="8" width="4" height="4" rx="0.5"/>
      <rect x="13" y="8" width="4" height="4" rx="0.5"/>
      <rect x="18" y="8" width="2" height="4" rx="0.5"/>
      <rect x="3" y="13" width="4" height="4" rx="0.5"/>
      <rect x="8" y="13" width="4" height="4" rx="0.5"/>
      <rect x="13" y="13" width="4" height="4" rx="0.5"/>
      <rect x="18" y="13" width="2" height="4" rx="0.5"/>
      <rect x="3" y="18" width="17" height="2" rx="0.5"/>
    </g>
  </svg>
);

const NotepadIcon = () => (
  <svg viewBox="0 0 24 24" className="w-10 h-10">
    <defs>
      <linearGradient id="noteGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: '#167AC6', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: '#065FD4', stopOpacity: 1}} />
      </linearGradient>
    </defs>
    <rect x="1" y="1" width="22" height="22" rx="3" fill="url(#noteGrad)"/>
    <g fill="#FFFFFF" opacity="0.85">
      <line x1="4" y1="5" x2="20" y2="5" stroke="#FFFFFF" strokeWidth="1" opacity="0.9"/>
      <line x1="4" y1="8" x2="20" y2="8" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.7"/>
      <line x1="4" y1="11" x2="20" y2="11" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.7"/>
      <line x1="4" y1="14" x2="20" y2="14" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.7"/>
      <line x1="4" y1="17" x2="16" y2="17" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.7"/>
      <line x1="4" y1="20" x2="12" y2="20" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.7"/>
    </g>
  </svg>
);

const EdgeIcon = () => (
  <svg viewBox="0 0 24 24" className="w-10 h-10">
    <defs>
      <linearGradient id="edgeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: '#065FD4', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: '#2E96E8', stopOpacity: 1}} />
      </linearGradient>
    </defs>
    <circle cx="12" cy="12" r="11" fill="url(#edgeGrad)"/>
    <path d="M12 3C7.03 3 3 7.03 3 12C3 16.97 7.03 21 12 21C16.97 21 21 16.97 21 12" stroke="#FFFFFF" strokeWidth="1.5" fill="none" opacity="0.8"/>
    <path d="M12 5C8.13 5 5 8.13 5 12C5 15.87 8.13 19 12 19C15.87 19 19 15.87 19 12" stroke="#FFFFFF" strokeWidth="1" fill="none" opacity="0.6"/>
  </svg>
);

const ExplorerIcon = () => (
  <svg viewBox="0 0 24 24" className="w-10 h-10">
    <defs>
      <linearGradient id="explorerGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: '#167AC6', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: '#065FD4', stopOpacity: 0.9}} />
      </linearGradient>
    </defs>
    <rect x="1" y="2" width="22" height="20" rx="3" fill="url(#explorerGrad)"/>
    <rect x="1" y="2" width="22" height="5" rx="3" fill="#2E96E8" opacity="0.9"/>
    <rect x="4" y="9" width="4" height="3" rx="0.5" fill="#FFFFFF" opacity="0.6"/>
    <rect x="10" y="9" width="4" height="3" rx="0.5" fill="#FFFFFF" opacity="0.6"/>
    <rect x="16" y="9" width="4" height="3" rx="0.5" fill="#FFFFFF" opacity="0.5"/>
  </svg>
);

const SettingsIcon = () => (
  <svg viewBox="0 0 24 24" className="w-10 h-10">
    <defs>
      <linearGradient id="settingsGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: '#065FD4', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: '#167AC6', stopOpacity: 1}} />
      </linearGradient>
    </defs>
    <circle cx="12" cy="12" r="11" fill="url(#settingsGrad)"/>
    <circle cx="12" cy="12" r="3" fill="#FFFFFF" opacity="0.85"/>
    <g stroke="#FFFFFF" strokeWidth="1.5" fill="none" opacity="0.75" strokeLinecap="round">
      <line x1="12" y1="1" x2="12" y2="3"/>
      <line x1="12" y1="21" x2="12" y2="23"/>
      <line x1="1" y1="12" x2="3" y2="12"/>
      <line x1="21" y1="12" x2="23" y2="12"/>
      <line x1="5.64" y1="5.64" x2="7.07" y2="4.22"/>
      <line x1="16.93" y1="19.78" x2="18.36" y2="18.36"/>
      <line x1="5.64" y1="18.36" x2="4.22" y2="19.78"/>
      <line x1="19.78" y1="4.22" x2="18.36" y2="5.64"/>
    </g>
  </svg>
);

const RecycleIcon = () => (
  <svg viewBox="0 0 24 24" className="w-10 h-10">
    <defs>
      <linearGradient id="recycleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: '#167AC6', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: '#2E96E8', stopOpacity: 1}} />
      </linearGradient>
    </defs>
    <rect x="1" y="2" width="22" height="20" rx="3" fill="url(#recycleGrad)"/>
    <path d="M8 9L12 15L16 9" stroke="#FFFFFF" strokeWidth="2" fill="none" opacity="0.85" strokeLinecap="round" strokeLinejoin="round"/>
    <line x1="6" y1="15" x2="18" y2="15" stroke="#FFFFFF" strokeWidth="1" opacity="0.65"/>
  </svg>
);

const ThisPCIcon = () => (
  <svg viewBox="0 0 24 24" className="w-10 h-10">
    <defs>
      <linearGradient id="pcGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{stopColor: '#065FD4', stopOpacity: 1}} />
        <stop offset="100%" style={{stopColor: '#167AC6', stopOpacity: 1}} />
      </linearGradient>
    </defs>
    <rect x="2" y="2" width="20" height="14" rx="2" fill="url(#pcGrad)"/>
    <rect x="8" y="17" width="8" height="3" rx="0.5" fill="#2E96E8" opacity="0.85"/>
    <circle cx="12" cy="9" r="2" fill="#FFFFFF" opacity="0.75"/>
    <rect x="3" y="3" width="18" height="12" rx="1" fill="#FFFFFF" opacity="0.08"/>
  </svg>
);

const desktopIcons = [
  { id: 'this-pc', appId: 'explorer', name: 'This PC', Icon: ThisPCIcon },
  { id: 'recycle-bin', appId: 'recycle-bin', name: 'Recycle Bin', Icon: RecycleIcon },
  { id: 'documents', appId: 'explorer', name: 'Documents', Icon: ExplorerIcon },
  { id: 'notepad', appId: 'notepad', name: 'Notepad', Icon: NotepadIcon },
  { id: 'calculator', appId: 'calculator', name: 'Calculator', Icon: CalculatorIcon },
  { id: 'settings', appId: 'settings', name: 'Settings', Icon: SettingsIcon },
  { id: 'edge', appId: 'edge', name: 'Microsoft Edge', Icon: EdgeIcon },
];

export function Desktop() {
  const { openWindow, showContextMenu, hideContextMenu } = useWindowsStore();

  const handleDoubleClick = (appId: string, name: string) => {
    if (appId === 'recycle-bin') return;
    
    const appConfig: Record<string, { width: number; height: number }> = {
      calculator: { width: 320, height: 500 },
      notepad: { width: 700, height: 500 },
      explorer: { width: 900, height: 600 },
      settings: { width: 1000, height: 700 },
      edge: { width: 1200, height: 800 },
    };
    
    const config = appConfig[appId] || { width: 800, height: 600 };
    openWindow(appId, name, config.width, config.height);
  };

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    showContextMenu(e.clientX, e.clientY, []);
  };

  return (
    <div 
      className="fixed inset-0 select-none overflow-hidden z-0" onClick={hideContextMenu}
      onContextMenu={handleContextMenu}

      data-testid="desktop"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-slate-100 to-cyan-50 dark:from-slate-950 dark:via-slate-920 dark:to-slate-900 pointer-events-none overflow-hidden">
        {/* Premium gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-cyan-100/10 via-transparent to-blue-100/5"></div>

        {/* Top-left premium glow */}
        <div className="absolute -top-56 -left-56 w-[700px] h-[700px] bg-gradient-to-br from-blue-300 via-blue-200 to-transparent rounded-full mix-blend-multiply filter blur-3xl opacity-25"></div>
        
        {/* Top center accent */}
        <div className="absolute -top-40 left-1/4 w-[600px] h-[600px] bg-cyan-300 rounded-full mix-blend-screen filter blur-3xl opacity-18"></div>
        
        {/* Right premium glow */}
        <div className="absolute top-1/3 -right-40 w-[650px] h-[650px] bg-gradient-to-bl from-blue-200 via-cyan-200 to-transparent rounded-full mix-blend-screen filter blur-3xl opacity-20"></div>
        
        {/* Bottom left accent */}
        <div className="absolute -bottom-48 -left-48 w-[600px] h-[600px] bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-18"></div>
        
        {/* Bottom right premium */}
        <div className="absolute -bottom-40 right-16 w-[550px] h-[550px] bg-cyan-100 rounded-full mix-blend-screen filter blur-3xl opacity-22"></div>

        {/* Center ambient glow */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-blue-200 rounded-full mix-blend-overlay filter blur-3xl opacity-12 animate-pulse" style={{animationDuration: '5s'}}></div>

        {/* Dark mode overlay adjustments */}
        <div className="dark:absolute dark:inset-0 dark:bg-gradient-to-br dark:from-blue-950/20 dark:via-slate-900/30 dark:to-slate-950/20"></div>
      </div>

      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(6,95,212,0.2)" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="relative z-10 pt-8 pl-8 pointer-events-auto">
        {/* First row: This PC and Edge side by side */}
        <div className="flex gap-4 mb-4 pointer-events-auto">
          {desktopIcons.slice(0, 1).map((icon) => (
            <div
              key={icon.id}
              onDoubleClick={() => handleDoubleClick(icon.appId, icon.name)}
              onContextMenu={handleContextMenu}
              className="desktop-icon w-20 cursor-pointer pointer-events-auto select-none group"
              data-testid={`icon-${icon.id}`}
            >
              <div className="flex flex-col items-center gap-2">
                <div className="w-14 h-14 flex items-center justify-center">
                  <icon.Icon />
                </div>
                <p className="text-xs text-foreground text-center leading-tight group-hover:text-primary truncate w-20">
                  {icon.name}
                </p>
              </div>
            </div>
          ))}
          {desktopIcons.filter(i => i.id === 'edge').map((icon) => (
            <div
              key={icon.id}
              onDoubleClick={() => handleDoubleClick(icon.appId, icon.name)}
              onContextMenu={handleContextMenu}
              className="desktop-icon w-20 cursor-pointer pointer-events-auto select-none group"
              data-testid={`icon-${icon.id}`}
            >
              <div className="flex flex-col items-center gap-2">
                <div className="w-14 h-14 flex items-center justify-center">
                  <icon.Icon />
                </div>
                <p className="text-xs text-foreground text-center leading-tight group-hover:text-primary truncate w-20">
                  {icon.name}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Remaining icons vertical */}
        <div className="space-y-4">
          {desktopIcons.filter(i => i.id !== 'this-pc' && i.id !== 'edge').map((icon) => (
            <div
              key={icon.id}
              onDoubleClick={() => handleDoubleClick(icon.appId, icon.name)}
              onContextMenu={handleContextMenu}
              className="desktop-icon w-20 cursor-pointer pointer-events-auto select-none group"
              data-testid={`icon-${icon.id}`}
            >
              <div className="flex flex-col items-center gap-2">
                <div className="w-14 h-14 flex items-center justify-center">
                  <icon.Icon />
                </div>
                <p className="text-xs text-foreground text-center leading-tight group-hover:text-primary truncate w-20">
                  {icon.name}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
