import { useWindowsStore } from '@/lib/windows-store';
import { 
  Cloud, 
  Sun, 
  CloudRain,
  Wind,
  Calendar,
  TrendingUp,
  TrendingDown,
  Newspaper,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { useRef, useEffect } from 'react';

const weatherData = {
  temp: 72,
  condition: 'Partly Cloudy',
  high: 78,
  low: 65,
  humidity: 45,
  wind: 12,
  forecast: [
    { day: 'Tue', temp: 75, icon: Sun },
    { day: 'Wed', temp: 68, icon: CloudRain },
    { day: 'Thu', temp: 71, icon: Cloud },
    { day: 'Fri', temp: 76, icon: Sun },
  ]
};

const stockData = [
  { symbol: 'MSFT', name: 'Microsoft', price: 378.91, change: 2.34, up: true },
  { symbol: 'AAPL', name: 'Apple', price: 189.25, change: -1.12, up: false },
  { symbol: 'GOOGL', name: 'Alphabet', price: 141.80, change: 0.89, up: true },
  { symbol: 'AMZN', name: 'Amazon', price: 178.35, change: 1.56, up: true },
];

const newsItems = [
  { title: 'Tech industry sees surge in AI investments', source: 'Tech News', time: '2h ago' },
  { title: 'New Windows 11 features rolling out this month', source: 'Microsoft Blog', time: '4h ago' },
  { title: 'Climate summit reaches historic agreement', source: 'World News', time: '6h ago' },
];

const calendarEvents = [
  { title: 'Team Meeting', time: '10:00 AM', color: 'bg-blue-500' },
  { title: 'Lunch with Sarah', time: '12:30 PM', color: 'bg-green-500' },
  { title: 'Project Review', time: '3:00 PM', color: 'bg-purple-500' },
];

export function WidgetsPanel() {
  const { widgetsOpen, closeWidgets, darkMode } = useWindowsStore();
  const widgetRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (widgetRef.current) {
      widgetRef.current.style.backgroundColor = darkMode 
        ? 'rgba(20, 25, 40, 0.95)' 
        : 'rgba(255, 255, 255, 0.95)';
    }
  }, [darkMode]);

  const today = new Date();
  const dayName = today.toLocaleDateString('en-US', { weekday: 'long' });
  const dateStr = today.toLocaleDateString('en-US', { month: 'long', day: 'numeric' });

  return (
    <AnimatePresence>
      {widgetsOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0"
            onClick={closeWidgets}
            data-testid="widgets-backdrop"
          />
          <motion.div
            ref={widgetRef}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="fixed left-2 top-2 bottom-14 w-[420px] win-acrylic win-border win-shadow rounded-lg z-50 overflow-hidden flex flex-col text-foreground"
            data-testid="widgets-panel"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="text-lg font-semibold text-foreground">Widgets</h2>
              <button
                className="p-1.5 rounded-md hover:bg-accent"
                onClick={closeWidgets}
                data-testid="button-close-widgets"
              >
                <X className="w-4 h-4 text-foreground" />
              </button>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-auto p-4 space-y-4">
              {/* Weather Widget */}
              <Card className="p-4 bg-gradient-to-br from-blue-400 to-blue-500 text-foreground border-0">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="text-5xl font-light">{weatherData.temp}°</div>
                    <div className="text-sm opacity-90">{weatherData.condition}</div>
                    <div className="text-xs opacity-75 mt-1">
                      H: {weatherData.high}° L: {weatherData.low}°
                    </div>
                  </div>
                  <Cloud className="w-16 h-16 opacity-90" />
                </div>
                <div className="flex items-center justify-between pt-3 border-t border-primary/20">
                  {weatherData.forecast.map(({ day, temp, icon: Icon }) => (
                    <div key={day} className="flex flex-col items-center gap-1">
                      <span className="text-xs opacity-75">{day}</span>
                      <Icon className="w-5 h-5" />
                      <span className="text-sm">{temp}°</span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Calendar Widget */}
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Calendar className="w-5 h-5 text-primary" />
                  <div>
                    <div className="text-sm font-medium text-foreground">{dayName}</div>
                    <div className="text-xs text-muted-foreground">{dateStr}</div>
                  </div>
                </div>
                <div className="space-y-2">
                  {calendarEvents.map(({ title, time, color }, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div className={`w-1 h-8 rounded-full ${color}`} />
                      <div>
                        <div className="text-sm text-foreground">{title}</div>
                        <div className="text-xs text-muted-foreground">{time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Stocks Widget */}
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span className="text-sm font-medium text-foreground">Markets</span>
                </div>
                <div className="space-y-2">
                  {stockData.map(({ symbol, name, price, change, up }) => (
                    <div key={symbol} className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium text-foreground">{symbol}</div>
                        <div className="text-xs text-muted-foreground">{name}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-foreground">${price}</div>
                        <div className={`text-xs flex items-center gap-1 ${up ? 'text-green-500' : 'text-red-500'}`}>
                          {up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                          {up ? '+' : ''}{change}%
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* News Widget */}
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Newspaper className="w-5 h-5 text-primary" />
                  <span className="text-sm font-medium text-foreground">Top Stories</span>
                </div>
                <div className="space-y-3">
                  {newsItems.map(({ title, source, time }, index) => (
                    <div key={index} className="group cursor-pointer">
                      <div className="text-sm text-foreground group-hover:text-primary transition-colors">
                        {title}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {source} · {time}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Wind/Humidity Info */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Wind className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Wind</span>
                  </div>
                  <div className="text-2xl font-light text-foreground">{weatherData.wind} mph</div>
                </Card>
                <Card className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Cloud className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">Humidity</span>
                  </div>
                  <div className="text-2xl font-light text-foreground">{weatherData.humidity}%</div>
                </Card>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
