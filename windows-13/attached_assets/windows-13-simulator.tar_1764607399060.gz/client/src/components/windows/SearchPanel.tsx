import { useWindowsStore } from '@/lib/windows-store';
import { Search, Clock, X, Folder, Settings, FileText, Calculator, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useState, useRef, useEffect } from 'react';

const recentSearches = [
  'Weather',
  'Settings',
  'Calculator',
  'Documents',
];

const topApps = [
  { id: 'edge', Icon: Globe, name: 'Microsoft Edge' },
  { id: 'explorer', Icon: Folder, name: 'File Explorer' },
  { id: 'settings', Icon: Settings, name: 'Settings' },
  { id: 'notepad', Icon: FileText, name: 'Notepad' },
  { id: 'calculator', Icon: Calculator, name: 'Calculator' },
];

export function SearchPanel() {
  const { searchOpen, closeSearch, openWindow, darkMode } = useWindowsStore();
  const [searchQuery, setSearchQuery] = useState('');
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (panelRef.current) {
      panelRef.current.style.backgroundColor = darkMode 
        ? 'rgba(20, 25, 40, 0.95)' 
        : 'rgba(255, 255, 255, 0.95)';
    }
  }, [darkMode]);

  const handleAppClick = (appId: string, name: string) => {
    const appConfig: Record<string, { width: number; height: number }> = {
      calculator: { width: 320, height: 500 },
      notepad: { width: 700, height: 500 },
      explorer: { width: 900, height: 600 },
      settings: { width: 1000, height: 700 },
      edge: { width: 1200, height: 800 },
    };
    
    const config = appConfig[appId] || { width: 800, height: 600 };
    openWindow(appId, name, config.width, config.height);
    closeSearch();
    setSearchQuery('');
  };

  const filteredApps = searchQuery
    ? topApps.filter(app => 
        app.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : topApps;

  return (
    <AnimatePresence>
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0"
          onClick={closeSearch}
          data-testid="search-backdrop"
        />
        <motion.div
          ref={panelRef}
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className="w-[95%] sm:w-[90%] md:w-[600px] max-w-[600px] max-h-[80vh] win-acrylic win-border win-shadow rounded-lg overflow-hidden text-foreground"
          data-testid="search-panel"
        >
            {/* Search Input */}
            <div className="p-4 border-b border-border">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Type here to search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full h-12 pl-12 pr-4 rounded-md bg-background/80 dark:bg-card/50 border border-border text-base focus:outline-none focus:ring-2 focus:ring-primary"
                  autoFocus
                  data-testid="input-search"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2"
                    data-testid="button-clear-search"
                  >
                    <X className="w-4 h-4 text-muted-foreground" />
                  </button>
                )}
              </div>
            </div>

            {/* Content */}
            <div className="p-4 overflow-auto" style={{ maxHeight: 'calc(80vh - 80px)' }}>
              {!searchQuery && (
                <>
                  {/* Recent Searches */}
                  <div className="mb-6">
                    <h3 className="text-xs font-semibold text-muted-foreground mb-2">Recent</h3>
                    <div className="space-y-1">
                      {recentSearches.map((search, index) => (
                        <button
                          key={index}
                          className="flex items-center gap-3 w-full px-3 py-2 rounded-md hover:bg-accent text-left"
                          onClick={() => setSearchQuery(search)}
                          data-testid={`recent-search-${index}`}
                        >
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-foreground">{search}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {/* Top Apps */}
              <div>
                <h3 className="text-xs font-semibold text-muted-foreground mb-2">
                  {searchQuery ? 'Results' : 'Top apps'}
                </h3>
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                  {filteredApps.map(({ id, Icon, name }) => (
                    <button
                      key={id}
                      className="pinned-app"
                      onClick={() => handleAppClick(id, name)}
                      data-testid={`search-app-${id}`}
                    >
                      <Icon className="w-8 h-8 text-foreground mb-1" strokeWidth={1.5} />
                      <span className="text-xs text-center text-foreground truncate w-full">
                        {name}
                      </span>
                    </button>
                  ))}
                </div>
                {searchQuery && filteredApps.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    No results found for "{searchQuery}"
                  </p>
                )}
              </div>
            </div>
        </motion.div>
      </>
    </AnimatePresence>
  );
}
