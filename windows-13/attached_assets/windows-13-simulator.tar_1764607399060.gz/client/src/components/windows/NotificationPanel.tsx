import { X, Volume2, Wifi, Moon, Sun } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useWindowsStore } from '@/lib/windows-store';
import { useState, useRef, useEffect } from 'react';

export function NotificationPanel() {
  const { notificationPanelOpen, closeNotificationPanel, darkMode } = useWindowsStore();
  const [volume, setVolume] = useState(75);
  const [brightness, setBrightness] = useState(100);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (notifRef.current) {
      notifRef.current.style.backgroundColor = darkMode 
        ? 'rgba(20, 25, 40, 0.95)' 
        : 'rgba(255, 255, 255, 0.95)';
    }
  }, [darkMode]);

  return (
    <AnimatePresence>
      {notificationPanelOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0"
            onClick={closeNotificationPanel}
            data-testid="notification-panel-backdrop"
          />
          <motion.div
            ref={notifRef}
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="fixed bottom-14 right-2 w-96 win-acrylic win-border win-shadow rounded-lg z-50 p-4 text-foreground"
            data-testid="notification-panel"
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">Quick Settings</h3>
              <button 
                onClick={closeNotificationPanel}
                className="p-1 hover:bg-accent/50 rounded-md transition-colors"
                data-testid="button-close-notification-panel"
              >
                <X className="w-4 h-4 text-foreground" />
              </button>
            </div>

            {/* Quick Actions Grid */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              <button className="flex flex-col items-center gap-2 p-3 rounded-md hover:bg-accent/30 transition-colors" data-testid="quick-action-wifi">
                <Wifi className="w-5 h-5 text-primary" />
                <span className="text-xs text-foreground text-center">WiFi</span>
              </button>
              
              <button className="flex flex-col items-center gap-2 p-3 rounded-md hover:bg-accent/30 transition-colors" data-testid="quick-action-volume">
                <Volume2 className="w-5 h-5 text-accent" />
                <span className="text-xs text-foreground text-center">Sound</span>
              </button>
              
              <button className="flex flex-col items-center gap-2 p-3 rounded-md hover:bg-accent/30 transition-colors" data-testid="quick-action-nightlight">
                <Moon className="w-5 h-5 text-primary" />
                <span className="text-xs text-foreground text-center">Night light</span>
              </button>
              
              <button className="flex flex-col items-center gap-2 p-3 rounded-md hover:bg-accent/30 transition-colors" data-testid="quick-action-brightness">
                <Sun className="w-5 h-5 text-accent" />
                <span className="text-xs text-foreground text-center">Brightness</span>
              </button>
            </div>

            {/* Sliders */}
            <div className="space-y-4 pt-3 border-t border-border">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-medium text-foreground">Volume</label>
                  <span className="text-xs text-muted-foreground">{volume}%</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  value={volume}
                  onChange={(e) => setVolume(parseInt(e.target.value))}
                  className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-accent"
                  data-testid="slider-notification-volume"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-medium text-foreground">Brightness</label>
                  <span className="text-xs text-muted-foreground">{brightness}%</span>
                </div>
                <input 
                  type="range" 
                  min="0" 
                  max="100" 
                  value={brightness}
                  onChange={(e) => setBrightness(parseInt(e.target.value))}
                  className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-accent"
                  data-testid="slider-notification-brightness"
                />
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
