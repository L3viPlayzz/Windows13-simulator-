// Play Windows 11 startup sound from audio file
export function playStartupSound() {
  try {
    const audio = new Audio('/windows-startup.mp3');
    audio.volume = 0.5;
    audio.play().catch(e => console.error('Failed to play audio:', e));
  } catch (e) {
    console.error('Audio error:', e);
  }
}
