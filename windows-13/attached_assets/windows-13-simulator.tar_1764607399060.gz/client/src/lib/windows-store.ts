import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { FileItem, AppSettings } from '@shared/schema';

export type { FileItem, AppSettings };

export interface WindowState {
  id: string;
  appId: string;
  title: string;
  isMinimized: boolean;
  isMaximized: boolean;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
}

export interface DesktopIcon {
  id: string;
  appId: string;
  name: string;
  icon: string;
  x: number;
  y: number;
}

interface WindowsStore {
  windows: WindowState[];
  activeWindowId: string | null;
  startMenuOpen: boolean;
  actionCenterOpen: boolean;
  searchOpen: boolean;
  widgetsOpen: boolean;
  notificationPanelOpen: boolean;
  accountMenuOpen: boolean;
  contextMenu: { x: number; y: number; items: ContextMenuItem[] } | null;
  maxZIndex: number;
  darkMode: boolean;
  userName: string;
  
  files: FileItem[];
  currentFolderId: string | null;
  isLoadingFiles: boolean;
  
  notepadContent: string;
  
  isLocked: boolean;
  lockPassword: string;
  
  powerState: 'normal' | 'sleeping' | 'restarting' | 'shutdown';
  showingStartup: boolean;
  
  openWindow: (appId: string, title: string, width?: number, height?: number) => void;
  closeWindow: (id: string) => void;
  minimizeWindow: (id: string) => void;
  maximizeWindow: (id: string) => void;
  restoreWindow: (id: string) => void;
  focusWindow: (id: string) => void;
  moveWindow: (id: string, x: number, y: number) => void;
  resizeWindow: (id: string, width: number, height: number) => void;
  
  toggleStartMenu: () => void;
  closeStartMenu: () => void;
  toggleActionCenter: () => void;
  closeActionCenter: () => void;
  toggleSearch: () => void;
  closeSearch: () => void;
  toggleWidgets: () => void;
  closeWidgets: () => void;
  toggleNotificationPanel: () => void;
  closeNotificationPanel: () => void;
  toggleAccountMenu: () => void;
  closeAccountMenu: () => void;
  
  showContextMenu: (x: number, y: number, items: ContextMenuItem[]) => void;
  hideContextMenu: () => void;
  
  toggleDarkMode: () => void;
  
  setNotepadContent: (content: string) => void;
  setUserName: (name: string) => void;
  navigateToFolder: (folderId: string | null) => void;
  createFile: (name: string, type: 'folder' | 'file', parentId: string | null) => Promise<void>;
  setFiles: (files: FileItem[]) => void;
  loadFiles: () => Promise<void>;
  
  lockSystem: () => void;
  unlockSystem: (password: string) => boolean;
  setLockPassword: (password: string) => void;
  
  handleSleep: () => void;
  handleRestart: () => void;
  handleShutdown: () => void;
  setPowerState: (state: 'normal' | 'sleeping' | 'restarting' | 'shutdown') => void;
  setShowingStartup: (showing: boolean) => void;
}

export interface ContextMenuItem {
  label: string;
  icon?: string;
  action?: () => void;
  divider?: boolean;
  disabled?: boolean;
}

export const useWindowsStore = create<WindowsStore>(
  persist((set, get) => ({
  windows: [],
  activeWindowId: null,
  startMenuOpen: false,
  actionCenterOpen: false,
  searchOpen: false,
  widgetsOpen: false,
  notificationPanelOpen: false,
  accountMenuOpen: false,
  contextMenu: null,
  maxZIndex: 100,
  darkMode: true,
  userName: 'Levi van Iterson',
  powerState: 'normal',
  showingStartup: false,
  
  files: [],
  currentFolderId: null,
  isLoadingFiles: false,
  
  notepadContent: '',
  
  isLocked: false,
  lockPassword: '110911',
  
  openWindow: (appId, title, width = 800, height = 600) => {
    const { windows, maxZIndex } = get();
    const existingWindow = windows.find(w => w.appId === appId);
    
    if (existingWindow) {
      if (existingWindow.isMinimized) {
        set({
          windows: windows.map(w => 
            w.id === existingWindow.id 
              ? { ...w, isMinimized: false, zIndex: maxZIndex + 1 }
              : w
          ),
          activeWindowId: existingWindow.id,
          maxZIndex: maxZIndex + 1,
          startMenuOpen: false,
        });
      } else {
        get().focusWindow(existingWindow.id);
      }
      return;
    }
    
    const offset = windows.length * 30;
    const newWindow: WindowState = {
      id: `${appId}-${Date.now()}`,
      appId,
      title,
      isMinimized: false,
      isMaximized: false,
      x: 100 + offset,
      y: 50 + offset,
      width,
      height,
      zIndex: maxZIndex + 1,
    };
    
    set({
      windows: [...windows, newWindow],
      activeWindowId: newWindow.id,
      maxZIndex: maxZIndex + 1,
      startMenuOpen: false,
      searchOpen: false,
    });
  },
  
  closeWindow: (id) => {
    const { windows } = get();
    const remainingWindows = windows.filter(w => w.id !== id);
    const activeWindow = remainingWindows.length > 0 
      ? remainingWindows.reduce((a, b) => a.zIndex > b.zIndex ? a : b)
      : null;
    
    set({
      windows: remainingWindows,
      activeWindowId: activeWindow?.id ?? null,
    });
  },
  
  minimizeWindow: (id) => {
    set(state => ({
      windows: state.windows.map(w => 
        w.id === id ? { ...w, isMinimized: true } : w
      ),
      activeWindowId: state.activeWindowId === id ? null : state.activeWindowId,
    }));
  },
  
  maximizeWindow: (id) => {
    set(state => ({
      windows: state.windows.map(w => 
        w.id === id ? { ...w, isMaximized: true } : w
      ),
    }));
  },
  
  restoreWindow: (id) => {
    set(state => ({
      windows: state.windows.map(w => 
        w.id === id ? { ...w, isMaximized: false, isMinimized: false } : w
      ),
    }));
  },
  
  focusWindow: (id) => {
    const { maxZIndex, windows } = get();
    set({
      windows: windows.map(w => 
        w.id === id ? { ...w, zIndex: maxZIndex + 1, isMinimized: false } : w
      ),
      activeWindowId: id,
      maxZIndex: maxZIndex + 1,
      startMenuOpen: false,
      actionCenterOpen: false,
      searchOpen: false,
      widgetsOpen: false,
    });
  },
  
  moveWindow: (id, x, y) => {
    set(state => ({
      windows: state.windows.map(w => 
        w.id === id ? { ...w, x, y } : w
      ),
    }));
  },
  
  resizeWindow: (id, width, height) => {
    set(state => ({
      windows: state.windows.map(w => 
        w.id === id ? { ...w, width, height } : w
      ),
    }));
  },
  
  toggleStartMenu: () => {
    set(state => ({
      startMenuOpen: !state.startMenuOpen,
      actionCenterOpen: false,
      searchOpen: false,
      widgetsOpen: false,
      contextMenu: null,
    }));
  },
  
  closeStartMenu: () => set({ startMenuOpen: false }),
  
  toggleActionCenter: () => {
    set(state => ({
      actionCenterOpen: !state.actionCenterOpen,
      startMenuOpen: false,
      searchOpen: false,
      widgetsOpen: false,
      contextMenu: null,
    }));
  },
  
  closeActionCenter: () => set({ actionCenterOpen: false }),
  
  toggleSearch: () => {
    set(state => ({
      searchOpen: !state.searchOpen,
      startMenuOpen: false,
      actionCenterOpen: false,
      widgetsOpen: false,
      contextMenu: null,
    }));
  },
  
  closeSearch: () => set({ searchOpen: false }),
  
  toggleWidgets: () => {
    set(state => ({
      widgetsOpen: !state.widgetsOpen,
      startMenuOpen: false,
      actionCenterOpen: false,
      searchOpen: false,
      contextMenu: null,
    }));
  },
  
  closeWidgets: () => set({ widgetsOpen: false }),
  
  toggleNotificationPanel: () => {
    set(state => ({
      notificationPanelOpen: !state.notificationPanelOpen,
    }));
  },
  
  closeNotificationPanel: () => set({ notificationPanelOpen: false }),
  
  toggleAccountMenu: () => {
    set(state => ({
      accountMenuOpen: !state.accountMenuOpen,
    }));
  },
  
  closeAccountMenu: () => set({ accountMenuOpen: false }),
  
  showContextMenu: (x, y, items) => {
    set({
      contextMenu: { x, y, items },
      startMenuOpen: false,
      actionCenterOpen: false,
      searchOpen: false,
      widgetsOpen: false,
    });
  },
  
  hideContextMenu: () => set({ contextMenu: null }),
  
  toggleDarkMode: () => {
    const newDarkMode = !get().darkMode;
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('darkMode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('darkMode', 'false');
    }
    set({ darkMode: newDarkMode });
  },
  
  setNotepadContent: (content) => set({ notepadContent: content }),
  
  setUserName: (name) => set({ userName: name }),
  
  navigateToFolder: (folderId) => set({ currentFolderId: folderId }),
  
  createFile: async (name, type, parentId) => {
    try {
      const response = await fetch('/api/files', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, type, parentId }),
      });
      
      if (response.ok) {
        const newFile = await response.json();
        set(state => ({
          files: [...state.files, newFile],
        }));
      }
    } catch (error) {
      console.error('Failed to create file:', error);
    }
  },
  
  setFiles: (files) => set({ files }),
  
  loadFiles: async () => {
    set({ isLoadingFiles: true });
    try {
      const response = await fetch('/api/files');
      if (response.ok) {
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          const files = await response.json();
          set({ files, isLoadingFiles: false });
        } else {
          console.error('Invalid response type:', contentType);
          set({ isLoadingFiles: false });
        }
      } else {
        console.error('Failed to fetch files:', response.status);
        set({ isLoadingFiles: false });
      }
    } catch (error) {
      console.error('Failed to load files:', error);
      set({ isLoadingFiles: false });
    }
  },

  lockSystem: () => {
    set({ isLocked: true, accountMenuOpen: false });
  },

  unlockSystem: (password: string) => {
    const { lockPassword } = get();
    if (password === lockPassword) {
      set({ isLocked: false });
      return true;
    }
    return false;
  },

  setLockPassword: (password: string) => {
    set({ lockPassword: password });
  },

  setPowerState: (state: 'normal' | 'sleeping' | 'restarting' | 'shutdown') => {
    set({ powerState: state });
  },

  handleSleep: () => {
    set({ powerState: 'sleeping', accountMenuOpen: false });
    set(state => ({
      windows: state.windows.map(win => ({ ...win, isMinimized: true }))
    }));
    setTimeout(() => {
      set({ powerState: 'normal' });
    }, 4500);
  },

  handleRestart: () => {
    set({ powerState: 'restarting', accountMenuOpen: false, showingStartup: true });
    setTimeout(() => {
      window.location.reload();
    }, 3000);
  },

  handleShutdown: () => {
    set({ powerState: 'shutdown', accountMenuOpen: false, windows: [] });
  },

  setShowingStartup: (showing: boolean) => {
    set({ showingStartup: showing });
  },
}), {
  name: 'windows-store',
  partialize: (state) => ({
    windows: state.windows,
    notepadContent: state.notepadContent,
    darkMode: state.darkMode,
    userName: state.userName,
    showingStartup: state.showingStartup,
  }),
  onRehydrateStorage: () => (state) => {
    if (state) {
      state.powerState = 'normal';
    }
  },
}));

// Initialize dark mode
if (typeof document !== 'undefined') {
  document.documentElement.classList.add('dark');
}
