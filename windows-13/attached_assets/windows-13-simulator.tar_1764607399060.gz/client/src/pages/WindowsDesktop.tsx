import { useWindowsStore } from '@/lib/windows-store';
import { Desktop } from '@/components/windows/Desktop';
import { Taskbar } from '@/components/windows/Taskbar';
import { StartMenu } from '@/components/windows/StartMenu';
import { Window } from '@/components/windows/Window';
import { ActionCenter } from '@/components/windows/ActionCenter';
import { SearchPanel } from '@/components/windows/SearchPanel';
import { ContextMenu } from '@/components/windows/ContextMenu';
import { WidgetsPanel } from '@/components/windows/WidgetsPanel';
import { NotificationPanel } from '@/components/windows/NotificationPanel';
import { OverlayPortal } from '@/components/windows/OverlayPortal';
import { AccountMenu } from '@/components/windows/AccountMenu';
import { LockScreen } from '@/components/windows/LockScreen';
import { StartupAnimation } from '@/components/windows/StartupAnimation';
import { Calculator } from '@/components/windows/apps/Calculator';
import { Notepad } from '@/components/windows/apps/Notepad';
import { FileExplorer } from '@/components/windows/apps/FileExplorer';
import { Settings } from '@/components/windows/apps/Settings';
import { Edge } from '@/components/windows/apps/Edge';
import { useEffect, useCallback, useMemo } from 'react';

const appComponents: Record<string, () => JSX.Element> = {
  calculator: Calculator,
  notepad: Notepad,
  explorer: FileExplorer,
  settings: Settings,
  edge: Edge,
  'this-pc': FileExplorer,
  photos: () => <PlaceholderApp name="Photos" />,
  mail: () => <PlaceholderApp name="Mail" />,
  calendar: () => <PlaceholderApp name="Calendar" />,
  music: () => <PlaceholderApp name="Groove Music" />,
  video: () => <PlaceholderApp name="Movies & TV" />,
};

function PlaceholderApp({ name }: { name: string }) {
  return (
    <div className="h-full flex flex-col items-center justify-center bg-background dark:bg-card text-muted-foreground">
      <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-4">
        <span className="text-3xl text-primary">{name[0]}</span>
      </div>
      <h2 className="text-xl font-light text-foreground mb-2">{name}</h2>
      <p className="text-sm">This app is coming soon</p>
    </div>
  );
}

export default function WindowsDesktop() {
  const { 
    windows, 
    startMenuOpen, 
    actionCenterOpen,
    widgetsOpen,
    hideContextMenu, 
    closeStartMenu, 
    closeActionCenter, 
    closeSearch, 
    closeWidgets, 
    closeNotificationPanel,
    closeAccountMenu,
    notificationPanelOpen,
    accountMenuOpen,
    searchOpen,
    loadFiles,
    isLocked,
    showingStartup,
    setShowingStartup,
    toggleAccountMenu
  } = useWindowsStore();


  useEffect(() => {
    // Initialize dark mode from localStorage
    if (localStorage.getItem('darkMode') === 'true') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    loadFiles();
  }, [loadFiles]);

  const closeAllPanels = useCallback(() => {
    closeStartMenu();
    closeActionCenter();
    closeSearch();
    closeWidgets();
    closeNotificationPanel();
    closeAccountMenu();
  }, [closeStartMenu, closeActionCenter, closeSearch, closeWidgets, closeNotificationPanel, closeAccountMenu]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        hideContextMenu();
        closeAllPanels();
      }
    };

    const handleClick = () => hideContextMenu();

    window.addEventListener('keydown', handleKeyDown, { passive: true });
    window.addEventListener('click', handleClick, { passive: true });

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('click', handleClick);
    };
  }, [hideContextMenu, closeAllPanels]);

  const sortedWindows = useMemo(() => 
    [...windows].sort((a, b) => a.zIndex - b.zIndex),
    [windows]
  );

  return (
    <div 
      className="h-screen w-screen overflow-hidden relative select-none bg-background dark:bg-slate-950"
      data-testid="windows-desktop"
    >
      <LockScreen />
      {showingStartup && (
        <StartupAnimation onComplete={() => {
          setShowingStartup(false);
        }} />
      )}
      {!isLocked && (
        <>
          <Desktop />
          {sortedWindows.map(window => {
            const AppComponent = appComponents[window.appId];
            return (
              <Window key={window.id} window={window}>
                {AppComponent ? <AppComponent /> : <PlaceholderApp name={window.title} />}
              </Window>
            );
          })}
          <Taskbar />
          {startMenuOpen && (
            <OverlayPortal zIndex={50}>
              <StartMenu />
            </OverlayPortal>
          )}
          {searchOpen && (
            <OverlayPortal zIndex={47}>
              <SearchPanel />
            </OverlayPortal>
          )}
          {notificationPanelOpen && (
            <OverlayPortal zIndex={48}>
              <NotificationPanel />
            </OverlayPortal>
          )}
          {accountMenuOpen && (
            <OverlayPortal zIndex={45}>
              <AccountMenu />
            </OverlayPortal>
          )}
          {actionCenterOpen && (
            <OverlayPortal zIndex={49}>
              <ActionCenter />
            </OverlayPortal>
          )}
          {widgetsOpen && (
            <OverlayPortal zIndex={46}>
              <WidgetsPanel />
            </OverlayPortal>
          )}
          <ContextMenu />
        </>
      )}
    </div>
  );
}
